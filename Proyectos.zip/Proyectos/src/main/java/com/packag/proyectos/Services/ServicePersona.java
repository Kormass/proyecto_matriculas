/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services;

import com.packag.proyectos.models.Persona;
import java.util.List;

public interface ServicePersona {

    List<Persona> listarPersonas();
    
    Persona obtenerPersonaPorId(int id);
    
    List<Persona> obtenerPersonaPorDocumento(int numeroDocumento);
    
    int crearPersona(Persona persona);
    
    void editarPersona(int id, Persona persona);
    
    void eliminarPersona(int id);

}


