/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;


public class Direccion {
    private Persona persona;
    private int tipoCalle;
    private int numero;

    public Direccion(Persona persona, int tipoCalle, int numero) {
        this.persona = persona;
        this.tipoCalle = tipoCalle;
        this.numero = numero;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public int getTipoCalle() {
        return tipoCalle;
    }

    public void setTipoCalle(int tipoCalle) {
        this.tipoCalle = tipoCalle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    

    public void imprimir() {
        System.out.println("Persona: ");
        persona.imprimir();
        System.out.println("Tipo de Calle: " + tipoCalle);
        System.out.println("Número: " + numero);
    }
}
