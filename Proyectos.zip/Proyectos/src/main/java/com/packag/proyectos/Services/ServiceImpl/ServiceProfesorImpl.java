package com.packag.proyectos.Services.ServiceImpl;


import com.packag.proyectos.Services.ServiceProfesor;
import com.packag.proyectos.models.Profesor;
import com.packag.proyectos.models.Profesor;
import com.packag.proyectos.repository.ProfesoresRepository;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Jefferson Jair
 */
public class ServiceProfesorImpl implements ServiceProfesor{
    private final ProfesoresRepository crudRepositoryProfesor;

    public ServiceProfesorImpl(ProfesoresRepository crudRepositoryProfesor){
         this.crudRepositoryProfesor=crudRepositoryProfesor;
    }

    @Override
    public List<Profesor> listarProfesores() {
          return this.crudRepositoryProfesor.listarProfesores();    }

    @Override
    public Profesor obtenerProfesorPorDocumento(int numeroDocumento) {
    Profesor profesor = this.crudRepositoryProfesor.obtenerProfesorPorDocumento(numeroDocumento);
        return profesor;
    }

    @Override
    public void crearProfesor(Profesor nuevoProfesor) {
    this.crudRepositoryProfesor.crearProfesor(nuevoProfesor);
    }

    @Override
    public void actualizarProfesor(Profesor profesorActualizado) {
    this.crudRepositoryProfesor.actualizarProfesor(profesorActualizado);
    }

    @Override
    public void eliminarProfesor(int idProfesor) {
    this.crudRepositoryProfesor.eliminarProfesor(idProfesor);
    }
}
