/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;


public class Profesor {
    private int id;
    private Persona persona;
    private int departamentoId;

    // Constructor
    public Profesor(int id, Persona persona, int departamentoId) {
        this.id = id;
        this.persona = persona;
        this.departamentoId = departamentoId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public int getDepartamentoId() {
        return departamentoId;
    }

    public void setDepartamentoId(int departamentoId) {
        this.departamentoId = departamentoId;
    }
    
    public void imprimir() {
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + persona.getNombres() + " " + persona.getApellidos());
        System.out.println("Número de Documento: " + persona.getNumeroDocumento());
        System.out.println("Departamento ID: " + departamentoId);
    }
 }

