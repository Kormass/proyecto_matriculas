

package com.packag.proyectos.models;


public class Salon {
    private Edificio edificio;
    private String nombre;
    private int capacidad;

    public Salon(Edificio edificio, String nombre, int capacidad) {
        this.edificio = edificio;
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    public Edificio getEdificio() {
        return edificio;
    }

    public void setEdificio(Edificio edificio) {
        this.edificio = edificio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }


    public void imprimir() {
        System.out.println("Edificio: ");
        edificio.imprimir();
        System.out.println("Nombre: " + nombre);
        System.out.println("Capacidad: " + capacidad);
    }
}
