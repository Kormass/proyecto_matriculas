package com.packag.proyectos.models;

import java.text.SimpleDateFormat;
import java.util.Date;



public class Periodo {
    private int id;
    private int codigo;
    private Date ano;
    private int semestre;

    public Periodo(int id, int codigo, Date ano, int semestre) {
        this.id = id;
        this.codigo = codigo;
        this.ano = ano;
        this.semestre = semestre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getAno() {
        return ano;
    }

    public void setAno(Date ano) {
        this.ano = ano;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    
   public void imprimir() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    System.out.println("=================================");
    System.out.println("           Detalles del Periodo");
    System.out.println("=================================");
    System.out.println("Código: " + codigo);
    System.out.println("Año: " + dateFormat.format(ano));
    System.out.println("Semestre: " + semestre);
    System.out.println("=================================");
}
}