package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.repository.PeriodoRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PeriodoImpl implements PeriodoRepository {

    @Override
    public List<Periodo> listarPeriodos() {
        List<Periodo> periodos = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM periodo";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    Periodo periodo = mapResultSetToPeriodo(resultSet);
                    periodos.add(periodo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return periodos;
    }

    @Override
    public Periodo obtenerPeriodoPorId(int id) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM periodo WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return mapResultSetToPeriodo(resultSet);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void crearPeriodo(Periodo periodo) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "INSERT INTO periodo (codigo, ano, semestre) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, periodo.getCodigo());
                preparedStatement.setDate(2, new java.sql.Date(periodo.getAno().getTime()));
                preparedStatement.setInt(3, periodo.getSemestre());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void editarPeriodo(int id, Periodo periodo) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "UPDATE periodo SET codigo = ?, ano = ?, semestre = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, periodo.getCodigo());
                preparedStatement.setDate(2, new java.sql.Date(periodo.getAno().getTime()));
                preparedStatement.setInt(3, periodo.getSemestre());
                preparedStatement.setInt(4, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminarPeriodo(int id) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "DELETE FROM periodo WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   private Periodo mapResultSetToPeriodo(ResultSet resultSet) throws SQLException {
    int id = resultSet.getInt("id");
    int codigo = resultSet.getInt("codigo");
    java.sql.Date ano = resultSet.getDate("ano");
    int semestre = resultSet.getInt("semestre");

    return new Periodo(id, codigo, ano, semestre);
}
}
