/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Asignatura;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public interface AsignaturaRepository {
    Asignatura obtenerAsignaturaPorId(int id);
    List<Asignatura> listarAsignaturas();
    void crearAsignatura(Asignatura nuevaAsignatura);
    void actualizarAsignatura(Asignatura asignaturaActualizada);
    void eliminarAsignatura(int idAsignatura);
}
