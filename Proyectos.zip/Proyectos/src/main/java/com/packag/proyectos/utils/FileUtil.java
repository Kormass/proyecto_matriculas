package com.packag.proyectos.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class FileUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static void guardarObjetosEnArchivo(List<?> objetos, String nombreArchivo) {
        try {
            objectMapper.writeValue(new File(nombreArchivo), objetos);
            System.out.println("Información guardada correctamente en " + nombreArchivo);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al guardar la información en " + nombreArchivo);
        }
    }

    public static <T> List<T> listarObjetosDeArchivo(Class<T> tipoObjeto) {
        String nombreArchivo = "DatosJson.json";
        try {
            File archivo = new File(nombreArchivo);
            if (archivo.exists()) {
                return objectMapper.readValue(archivo, objectMapper.getTypeFactory().constructCollectionType(List.class, tipoObjeto));
            } else {
                System.err.println("El archivo " + nombreArchivo + " no existe.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al leer la información desde " + nombreArchivo);
        }
        return null;
    }
}
