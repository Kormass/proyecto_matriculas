package com.packag.proyectos.views;


import com.packag.proyectos.Excepciones.ExcepcionesPersona.PersonaNullException;
import com.packag.proyectos.Services.ServiceImpl.ServicePersonaImpl;
import com.packag.proyectos.Services.ServicePersona;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.views.ViewMain;
import static com.packag.proyectos.views.ViewMain.leer;
import java.sql.Date;

public class ViewPersona extends ViewMain {
    
   
    public static void startMenu() {
        int op = 0;

        do {
            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearPersona();
                    break;
                case 2:
                    listarPersonas();
                    break;
                case 3:
                    buscarPersona();
                    break;
                case 4:
                    modificarPersona();
                    break;
                case 5:
                    eliminarPersona();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);
    }

    public static int mostrarMenu() {
        System.out.println("----Menu--Persona----");
        System.out.println("1. Crear persona.");
        System.out.println("2. Listar personas.");
        System.out.println("3. Buscar persona.");
        System.out.println("4. Modificar persona.");
        System.out.println("5. Eliminar persona.");
        System.out.println("6. Salir ");
        return leer.nextInt();
    }

    private static void crearPersona() {
    leer.nextLine(); // Limpiar el buffer

    System.out.print("Tipo de Documento: ");
    String tipoDocumento = leer.nextLine();

    System.out.print("Numero de Documento: ");
    int numeroDocumento = leer.nextInt();
    leer.nextLine(); // Limpiar el buffer

    System.out.print("Nombres: ");
    String nombres = leer.nextLine();

    System.out.print("Apellidos: ");
    String apellidos = leer.nextLine();

    System.out.print("Direccion: ");
    String direccion = leer.nextLine();

    System.out.print("Telefono: ");
    int telefono = leer.nextInt();
    leer.nextLine(); // Limpiar el buffer

    System.out.print("Fecha de Nacimiento (YYYY-MM-DD): ");
    String fechaNacimientoStr = leer.nextLine();
    Date fechaNacimiento = Date.valueOf(fechaNacimientoStr);

    System.out.print("Sexo: ");
    String sexo = leer.nextLine();

    Persona persona = new Persona(tipoDocumento, numeroDocumento, nombres, apellidos, direccion, telefono, fechaNacimiento, sexo);
    servicePersona.crearPersona(persona);
}


    private static void listarPersonas() {
        System.out.println("Lista de Personas");
        for (Persona persona : servicePersona.listarPersonas()) {
            persona.imprimir();
            System.out.println();
        }
    }

    private static void buscarPersona() {
        System.out.println("Busqueda de persona ");
        leer.nextLine();
        System.out.print("Documento: ");
        int numeroDocumento = leer.nextInt();

        Persona persona = (Persona) servicePersona.obtenerPersonaPorDocumento(numeroDocumento);
        System.out.println();
        persona.imprimir();
    }

    private static void modificarPersona() {
        // Implementa la lógica de modificación aquí
    }

    private static void eliminarPersona() {
        // Implementa la lógica de eliminación aquí
    }
}
