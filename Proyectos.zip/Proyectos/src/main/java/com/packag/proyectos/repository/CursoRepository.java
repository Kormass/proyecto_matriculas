/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Curso;
import java.util.List;

public interface CursoRepository {
    List<Curso> listarCursos();
    Curso obtenerCursoPorId(int id);
    void crearCurso(Curso curso);
    void editarCurso(int id, Curso curso);
    void eliminarCurso(int id);
}
