/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.repository.CreditosRepository;
import com.packag.proyectos.repository.AsignaturaRepository;
import java.util.List;
import com.packag.proyectos.models.Asignatura;
import com.packag.proyectos.models.Creditos;
import com.packag.proyectos.models.Horario;
import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.models.Profesor;
import com.packag.proyectos.models.Programa;
import com.packag.proyectos.models.Salon;
import com.packag.proyectos.repository.HorariosRepository;
import com.packag.proyectos.repository.PeriodoRepository;
import com.packag.proyectos.repository.PersonaRepository;
import com.packag.proyectos.repository.ProfesoresRepository;
import com.packag.proyectos.repository.ProgramasRepository;
import com.packag.proyectos.repository.SalonesRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AsignaturaRepositoryImpl implements AsignaturaRepository {

    private ProfesoresRepository profesoresRepository;
    private PeriodoRepository periodoRepository;
    private ProgramasRepository programaRepository;
    private CreditosRepository creditosRepository;
    private HorariosRepository horarioRepository;
    private SalonesRepository salonRepository;
    private PersonaRepository personaRepository;

    public AsignaturaRepositoryImpl(ProfesoresRepository profesoresRepository, 
                                    PeriodoRepository periodoRepository,
                                    ProgramasRepository programaRepository,
                                    CreditosRepository creditosRepository,
                                    HorariosRepository horarioRepository,
                                    SalonesRepository salonRepository,
                                    PersonaRepository personaRepository) {
        this.profesoresRepository = profesoresRepository;
        this.periodoRepository = periodoRepository;
        this.programaRepository = programaRepository;
        this.creditosRepository = creditosRepository;
        this.horarioRepository = horarioRepository;
        this.salonRepository = salonRepository;
        this.personaRepository = personaRepository;
    }

    @Override
public Asignatura obtenerAsignaturaPorId(int id) {
    Asignatura asignatura = null;

    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "SELECT * FROM asignaturas WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Profesor profesor = profesoresRepository.obtenerProfesorPorDocumento(resultSet.getInt("id_profesor"));
                    Periodo periodo = periodoRepository.obtenerPeriodoPorId(resultSet.getInt("id_periodo"));
                    Programa programa = programaRepository.obtenerProgramaPorId(resultSet.getInt("id_programa"));
                    Creditos creditos = creditosRepository.obtenerCreditosPorId(resultSet.getInt("id_creditos"));
                    Horario horario = horarioRepository.obtenerHorarioPorId(resultSet.getInt("id_horario"));
                    Salon salon = salonRepository.obtenerSalonPorId(resultSet.getInt("id_salon"));

                    Persona persona = personaRepository.obtenerPersonaPorId(resultSet.getInt("id_persona"));

                    asignatura = new Asignatura(
                            resultSet.getInt("id"),
                            profesor,
                            periodo,
                            programa,
                            resultSet.getString("nombre"),
                            creditos,
                            resultSet.getString("lugares_disponibles"),
                            horario,
                            salon
                    );
                }
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }

    return asignatura;
}


    private Persona mapResultSetToPersona(ResultSet resultSet) throws SQLException {
        return new Persona(
                resultSet.getString("t_documento"),
                resultSet.getInt("n_documento"),
                resultSet.getString("nombres"),
                resultSet.getString("apellidos"),
                resultSet.getString("direccion"),
                resultSet.getInt("telefono"),
                resultSet.getDate("f_nacimiento"),
                resultSet.getString("sexo")
        );
    }




    @Override
public List<Asignatura> listarAsignaturas() {
    List<Asignatura> listaAsignaturas = new ArrayList<>();

    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "SELECT * FROM asignaturas";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {

                    Profesor profesor = profesoresRepository.obtenerProfesorPorDocumento(resultSet.getInt("id_profesor"));
                    Periodo periodo = periodoRepository.obtenerPeriodoPorId(resultSet.getInt("id_periodo"));
                    Programa programa = programaRepository.obtenerProgramaPorId(resultSet.getInt("id_programa"));
                    Creditos creditos = creditosRepository.obtenerCreditosPorId(resultSet.getInt("id_creditos"));
                    Horario horario = horarioRepository.obtenerHorarioPorId(resultSet.getInt("id_horario"));
                    Salon salon = salonRepository.obtenerSalonPorId(resultSet.getInt("id_salon"));

                    Persona persona = personaRepository.obtenerPersonaPorId(resultSet.getInt("id_persona"));

                    Asignatura asignatura = new Asignatura(
                            resultSet.getInt("id"),
                            profesor,
                            periodo,
                            programa,
                            resultSet.getString("nombre"),
                            creditos,
                            resultSet.getString("lugares_disponibles"),
                            horario,
                            salon
                    );

                    listaAsignaturas.add(asignatura);
                }
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }

    return listaAsignaturas;
}


    @Override
public void crearAsignatura(Asignatura nuevaAsignatura) {
    try (Connection connection = ConexionBDMysql.getInstance()) {
        // Insertar en la tabla asignaturas
        String sql = "INSERT INTO asignaturas (id_programa, nombre, id_horario) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, nuevaAsignatura.getPrograma().getId());
            preparedStatement.setString(2, nuevaAsignatura.getNombre());
            preparedStatement.setInt(3, nuevaAsignatura.getHorario().getId());

            preparedStatement.executeUpdate();
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}


    @Override
    public void actualizarAsignatura(Asignatura asignaturaActualizada) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            // Actualizar datos en la tabla asignaturas
            String sql = "UPDATE asignaturas SET id_programa = ?, nombre = ?, id_horario = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, asignaturaActualizada.getPrograma().getId());
                preparedStatement.setString(2, asignaturaActualizada.getNombre());
                preparedStatement.setInt(3, asignaturaActualizada.getHorario().getId());
                preparedStatement.setInt(4, asignaturaActualizada.getId());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }



    @Override
    public void eliminarAsignatura(int idAsignatura) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            // Eliminar la asignatura de la tabla asignaturas
            String sql = "DELETE FROM asignaturas WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, idAsignatura);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    


