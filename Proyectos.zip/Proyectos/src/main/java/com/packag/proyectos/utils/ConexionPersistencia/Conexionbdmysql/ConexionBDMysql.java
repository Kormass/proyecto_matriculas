/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.utils.Configuracion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexionBDMysql {

    private static String url = "jdbc:mysql://localhost:3306/matriculas";
    private static String username = Configuracion.obtenerValor("root");
    private static String password = Configuracion.obtenerValor("0000");
    private static Connection connection;

    public static Connection getInstance() throws SQLException {

        return connection = DriverManager.getConnection(url, username, password);

    }

}