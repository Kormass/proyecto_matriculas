/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Periodo;
import java.util.List;

public interface PeriodoRepository {
    List<Periodo> listarPeriodos();
    Periodo obtenerPeriodoPorId(int id);
    void crearPeriodo(Periodo periodo);
    void editarPeriodo(int id, Periodo periodo);
    void eliminarPeriodo(int id);
}
