/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;

import java.sql.Time;


public class Horario {
    private int id;
    private String dia;
    private Time horaInicio;
    private Time horaFin;

    public Horario(int id, String dia, Time horaInicio, Time horaFin) {
        this.id = id;
        this.dia = dia;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    public void imprimir() {
        System.out.println("Día: " + dia);
        System.out.println("Hora de Inicio: " + horaInicio);
        System.out.println("Hora de Fin: " + horaFin);
    }
}
