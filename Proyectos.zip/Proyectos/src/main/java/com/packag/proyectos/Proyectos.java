/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.packag.proyectos;

/**
 *
 * @author Jefferson Jair
 */
public class Proyectos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
