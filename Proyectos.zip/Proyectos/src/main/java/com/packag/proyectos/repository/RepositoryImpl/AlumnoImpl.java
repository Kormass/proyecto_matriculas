/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.models.Alumno;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.repository.AlumnoRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson.ConexionBDJsonAlumnos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public class AlumnoImpl implements AlumnoRepository {

    ConexionBDJsonAlumnos conexion = ConexionBDJsonAlumnos.getConexion();

    
    @Override
    public List<Alumno> listar() {
        return conexion.getData(Alumno.class);
    }

    @Override
    public Alumno porDocumento(String documento) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT alumnos.id as alumno_id, persona.id as persona_id, alumnos.*, persona.* " +
                         "FROM alumnos " +
                         "JOIN persona ON alumnos.id_persona = persona.id " +
                         "WHERE n_documento = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, documento);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        Persona persona = mapResultSetToPersona(resultSet);
                        Alumno alumno = new Alumno();
                        return alumno;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
    
    public Alumno buscarAlumnoPorDocumento(int numeroDocumento) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM alumnos JOIN persona ON alumnos.id_persona = persona.id WHERE n_documento = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, numeroDocumento);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        Persona persona = mapResultSetToPersona(resultSet);
                        Alumno alumno = new Alumno();
                        return alumno;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private Persona mapResultSetToPersona(ResultSet resultSet) throws SQLException {
    return new Persona(
            resultSet.getString("t_documento"),
            resultSet.getInt("n_documento"),
            resultSet.getString("nombres"),
            resultSet.getString("apellidos"),
            resultSet.getString("direccion"),
            resultSet.getInt("telefono"),
            resultSet.getDate("f_nacimiento"),
            resultSet.getString("sexo")
        );
    }

     @Override
    public void crear(Alumno alumno) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "INSERT INTO alumnos (id_persona) VALUES ((SELECT id FROM persona WHERE n_documento = ?))";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, alumno.getPersona().getNumeroDocumento());

                preparedStatement.executeUpdate();
                
                // Obtén el ID del alumno generado por la base de datos
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                    } else {
                        throw new SQLException("La creación del alumno no generó un ID.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        

    @Override
    public void editar(Alumno alumno) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "UPDATE alumnos SET id_persona = (SELECT id FROM persona WHERE n_documento = ?) WHERE id = ?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, alumno.getPersona().getNumeroDocumento());
                preparedStatement.setInt(2, alumno.getId());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(Alumno alumno) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "DELETE FROM alumnos WHERE id = ?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, alumno.getId());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    
}
