    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */
    package com.packag.proyectos.views;

    /**
     *
     * @author Jefferson Jair
     */
    import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
    import java.sql.Connection;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.sql.SQLException;
    import java.util.InputMismatchException;
    import java.util.Scanner;

    public class ViewMatricula {

        public static final Scanner leer = new Scanner(System.in);

        public static void startMenu() {
            int opcion = 0;

            do {
        opcion = menuMatricula();
        switch (opcion) {
            case 1:
                listarMatriculas();
                break;
            case 2:
                matricularAlumno(); // Llamada al método matricularAlumno()
                break;
            case 3:
                listarAsignaturasDisponibles();
                break;
            case 4:
                System.out.println("Volviendo al menú principal.");
                break;
            default:
                System.out.println("Opción no válida. Inténtalo de nuevo.");
                break;
        }
    } while (opcion >= 1 && opcion < 4);
    }
                public static int menuMatricula() {
            System.out.println("===============================================");
            System.out.println("              Módulo de Matrícula");
            System.out.println("===============================================");
            System.out.println("1. Listar Matrículas");
            System.out.println("2. Matricular Alumno");
            System.out.println("3. Asignaturas Disponibles");
            System.out.println("4. Volver al Menú Principal");
            System.out.println("===============================================");
            System.out.print("Ingrese su opción: ");
            return leer.nextInt();


        }

       public static void listarMatriculas() {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT m.id AS id_matricula, a.id AS id_alumno, a.id_persona, "
                       + "p.nombres, p.apellidos, p.telefono, m.id_curso "
                       + "FROM matriculas m "
                       + "JOIN alumnos a ON m.id_alumno = a.id "
                       + "JOIN persona p ON a.id_persona = p.id";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                System.out.println("===============================================");
                System.out.println("           Listado de Matrículas");
                System.out.println("===============================================");

                while (resultSet.next()) {
                    int idMatricula = resultSet.getInt("id_matricula");
                    int idAlumno = resultSet.getInt("id_alumno");
                    String nombres = resultSet.getString("nombres");
                    String apellidos = resultSet.getString("apellidos");
                    int telefono = resultSet.getInt("telefono");
                    int idCurso = resultSet.getInt("id_curso");

                    System.out.println("ID Matrícula: " + idMatricula);
                    System.out.println("ID Alumno: " + idAlumno);
                    System.out.println("Nombre: " + nombres + " " + apellidos);
                    System.out.println("Teléfono: " + telefono);
                    System.out.println("ID Curso: " + idCurso);
                    System.out.println("-----------------------------------------------");
                }

                System.out.println("===============================================");

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.err.println("Error al listar las matrículas.");
        }
    }

    public static void matricularAlumno() {
        try {
            System.out.println("===============================================");
            System.out.println("          Matricular Nuevo Alumno");
            System.out.println("===============================================");

            System.out.println("Ingrese el ID del alumno: ");
            int idAlumno = leer.nextInt();

            System.out.println("Ingrese el ID del curso: ");
            int idCurso = leer.nextInt();

            if (realizarMatricula(idAlumno, idCurso)) {
                System.out.println("Matrícula exitosa.");
            } else {
                System.out.println("Error al matricular al alumno.");
            }

            System.out.println("===============================================");

        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese números válidos.");
            leer.nextLine(); // Limpiar el buffer
        }
    }


    // Método para realizar la matrícula en la base de datos
     public static boolean realizarMatricula(int idAlumno, int idCurso) {
            try (Connection connection = ConexionBDMysql.getInstance()) {
                // Verificar si el alumno y el curso existen antes de realizar la matrícula
                if (alumnoExiste(connection, idAlumno) && cursoExiste(connection, idCurso)) {
                    // Insertar la matrícula en la tabla de matrículas
                    String sql = "INSERT INTO matriculas (id_alumno, id_curso) VALUES (?, ?)";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                        preparedStatement.setInt(1, idAlumno);
                        preparedStatement.setInt(2, idCurso);
                        int filasAfectadas = preparedStatement.executeUpdate();

                        return filasAfectadas > 0;  // Retorna true si se insertó al menos una fila
                    }
                } else {
                    System.out.println("El alumno o el curso no existen.");
                    return false;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                System.err.println("Error al realizar la matrícula.");
                return false;
            }
        }

        private static boolean alumnoExiste(Connection connection, int idAlumno) throws SQLException {
            String sql = "SELECT COUNT(*) FROM alumnos WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, idAlumno);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    resultSet.next();
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        private static boolean cursoExiste(Connection connection, int idCurso) throws SQLException {
            String sql = "SELECT COUNT(*) FROM curso WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, idCurso);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    resultSet.next();
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }
        // Agrega este método en tu clase ViewMatricula
           public static void listarAsignaturasDisponibles() {
    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "SELECT a.id AS id_asignatura, a.nombre, p.nombres, p.apellidos "
                   + "FROM asignaturas a "
                   + "JOIN profesores pr ON a.id_profesor = pr.id "
                   + "JOIN persona p ON pr.id_persona = p.id";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            System.out.println("===============================================");
            System.out.println("      Listado de Asignaturas Disponibles");
            System.out.println("===============================================");

            while (resultSet.next()) {
                int idAsignatura = resultSet.getInt("id_asignatura");
                String nombreAsignatura = resultSet.getString("nombre");
                String nombresProfesor = resultSet.getString("nombres");
                String apellidosProfesor = resultSet.getString("apellidos");

                System.out.println("ID Asignatura: " + idAsignatura);
                System.out.println("Nombre Asignatura: " + nombreAsignatura);
                System.out.println("Profesor: " + nombresProfesor + " " + apellidosProfesor);
                System.out.println("-----------------------------------------------");
            }

            System.out.println("===============================================");

        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        System.err.println("Error al listar las asignaturas disponibles.");
    }
}

}
    
