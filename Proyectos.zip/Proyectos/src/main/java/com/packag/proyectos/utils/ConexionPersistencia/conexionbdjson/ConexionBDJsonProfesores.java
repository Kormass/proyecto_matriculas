/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson;

import com.packag.proyectos.models.Profesor;



public class ConexionBDJsonProfesores extends ConexionBDJsonBase<Profesor> {

    private static ConexionBDJsonProfesores conexionProfesores;

    private ConexionBDJsonProfesores() {
        super("Profesores.json");
    }

    public static ConexionBDJsonProfesores getConexion() {
        if (conexionProfesores != null) {
            return conexionProfesores;
        } else {
            conexionProfesores = new ConexionBDJsonProfesores();
            return conexionProfesores;
        }
    }
    
}
