/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services;

import com.packag.proyectos.models.Alumno;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public interface ServiceAlumno {
    public abstract List<Alumno> listar();

    public abstract Alumno porDocumento(String documento);

    public abstract void crear(Alumno alumno);

    public abstract void editar(Alumno alumno);

    public abstract void eliminar(Alumno alumno);

}

