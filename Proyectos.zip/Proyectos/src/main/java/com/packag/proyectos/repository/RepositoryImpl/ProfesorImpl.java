/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository.RepositoryImpl;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.models.Profesor;
import com.packag.proyectos.repository.ProfesoresRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson.ConexionBDJsonProfesores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProfesorImpl implements ProfesoresRepository {

    // Otros métodos de la interfaz ProfesorRepository...
    ConexionBDJsonProfesores conexion = ConexionBDJsonProfesores.getConexion();
    
   public List<Profesor> listarProfesores() {
    List<Profesor> profesores = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT profesores.id as profesor_id, persona.id as persona_id, profesores.*, persona.* " +
                         "FROM profesores " +
                         "JOIN persona ON profesores.id_persona = persona.id";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    Persona persona = mapResultSetToPersona(resultSet);

                    // Crear un objeto Profesor utilizando el constructor con parámetros
                    Profesor profesor = new Profesor(
                        resultSet.getInt("profesor_id"),
                        persona,
                        resultSet.getInt("id_departamento")
                    );

                    profesores.add(profesor);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return profesores;
    }


    @Override
    public Profesor obtenerProfesorPorDocumento(int numeroDocumento) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT profesores.id as profesor_id, persona.id as persona_id, profesores.*, persona.* " +
                         "FROM profesores " +
                         "JOIN persona ON profesores.id_persona = persona.id " +
                         "WHERE n_documento = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, numeroDocumento);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        Persona persona = mapResultSetToPersona(resultSet);

                        // Crear un objeto Profesor utilizando el constructor con parámetros
                        Profesor profesor = new Profesor(
                            resultSet.getInt("profesor_id"),
                            persona,
                            resultSet.getInt("id_departamento")
                        );

                        return profesor;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void crearProfesor(Profesor nuevoProfesor) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "INSERT INTO profesores (id_persona, id_departamento) VALUES ((SELECT id FROM persona WHERE n_documento = ?), ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, nuevoProfesor.getPersona().getNumeroDocumento());
                preparedStatement.setInt(2, nuevoProfesor.getDepartamentoId());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizarProfesor(Profesor profesorActualizado) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "UPDATE profesores SET id_persona = (SELECT id FROM persona WHERE n_documento = ?), id_departamento = ? WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, profesorActualizado.getPersona().getNumeroDocumento());
                preparedStatement.setInt(2, profesorActualizado.getDepartamentoId());
                preparedStatement.setInt(3, profesorActualizado.getId());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void eliminarProfesor(int idProfesor) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "DELETE FROM profesores WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, idProfesor);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    private Persona mapResultSetToPersona(ResultSet resultSet) throws SQLException {
        return new Persona(
                resultSet.getInt("id"),
                resultSet.getString("t_documento"),
                resultSet.getInt("n_documento"),
                resultSet.getString("nombres"),
                resultSet.getString("apellidos"),
                resultSet.getString("direccion"),
                resultSet.getInt("telefono"),
                resultSet.getDate("f_nacimiento"),
                resultSet.getString("sexo")
        );
    }
}

