/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services.ServiceImpl;

import com.packag.proyectos.Excepciones.ExcepcionesPersona.PersonaNullException;
import com.packag.proyectos.Services.ServicePersona;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.repository.PersonaRepository;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jefferson Jair
 */
public class ServicePersonaImpl  implements ServicePersona {

    private final PersonaRepository crudRepositoryPersona;

    public ServicePersonaImpl(PersonaRepository crudRepositoryPersona){
         this.crudRepositoryPersona=crudRepositoryPersona;
    }

    @Override
    public List<Persona> listarPersonas() {
         return this.crudRepositoryPersona.listarPersonas();
    }

    @Override
    public Persona obtenerPersonaPorId(int id) {
    Persona persona = this.crudRepositoryPersona.obtenerPersonaPorId(id);
        if (persona != null) {
            return persona;
        } else {
        try {
            throw new PersonaNullException("No se encontro Persona por codigo");
        } catch (PersonaNullException ex) {
            Logger.getLogger(ServicePersonaImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        }   
        return persona;
    }

    @Override
    public List<Persona> obtenerPersonaPorDocumento(int numeroDocumento) {
    Persona persona = (Persona) this.crudRepositoryPersona.obtenerPersonaPorDocumento(numeroDocumento);
        return (List<Persona>) persona;
}

    @Override
    public void crearPersona(Persona persona) {
        this.crudRepositoryPersona.crearPersona(persona);
    }

    @Override
    public void editarPersona(int id, Persona persona) {
        this.crudRepositoryPersona.editarPersona(id,persona);
    }

    @Override
    public void eliminarPersona(int id) {
        this.crudRepositoryPersona.eliminarPersona(id);
    }

}


   