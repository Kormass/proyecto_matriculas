/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Creditos;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public interface CreditosRepository {
    List<Creditos> listarCreditos();
    Creditos obtenerCreditosPorId(int id);
    void crearCreditos(Creditos Creditos);
    void editarCreditos(int id, Creditos Creditos);
    void eliminarCreditos(int id);
}
