/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.models.Persona;
import com.packag.proyectos.repository.PersonaRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson.ConexionBDJsonPersonas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public class PersonaImpl implements PersonaRepository{
    
    ConexionBDJsonPersonas conexion = ConexionBDJsonPersonas.getConexion();
    
    @Override
    public List<Persona> listarPersonas() {
        return conexion.getData(Persona.class);   
    }

    @Override
    public Persona obtenerPersonaPorId(int id) {
        Persona persona = null;

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM persona WHERE id = ?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        
                        persona = new Persona(
                            resultSet.getString("t_documento"),
                            resultSet.getInt("n_documento"),
                            resultSet.getString("nombres"),
                            resultSet.getString("apellidos"),
                            resultSet.getString("direccion"),
                            resultSet.getInt("telefono"),
                            resultSet.getDate("f_nacimiento"),
                            resultSet.getString("sexo")
                        );
                    }
                }
            }
        } catch (SQLException e) {
        }

        return persona;
    }

    @Override
    public List<Persona> obtenerPersonaPorDocumento(int numeroDocumento) {
        List<Persona> personas = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM persona WHERE n_documento = ?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, numeroDocumento);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        // Asegúrate de tener la lógica adecuada para mapear los datos
                        // Aquí deberías instanciar objetos Persona y establecer sus atributos
                        // Puedes acceder a las columnas específicas con resultSet.getString("nombre_columna")
                        // y resultSet.getInt("nombre_columna") según el tipo de datos.
                        // Por ejemplo:
                        Persona persona = new Persona(
                            resultSet.getString("t_documento"),
                            resultSet.getInt("n_documento"),
                            resultSet.getString("nombres"),
                            resultSet.getString("apellidos"),
                            resultSet.getString("direccion"),
                            resultSet.getInt("telefono"),
                            resultSet.getDate("f_nacimiento"),
                            resultSet.getString("sexo")
                        );
                        personas.add(persona);
                    }
                }
            }
        } catch (SQLException e) {
        }

        return personas;
    }

    @Override
    public void crearPersona(Persona persona) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "INSERT INTO persona (t_documento, n_documento, nombres, apellidos, direccion, telefono, f_nacimiento, sexo) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, persona.getTipoDocumento());
                preparedStatement.setInt(2, persona.getNumeroDocumento());
                preparedStatement.setString(3, persona.getNombres());
                preparedStatement.setString(4, persona.getApellidos());
                preparedStatement.setString(5, persona.getDireccion());
                preparedStatement.setInt(6, persona.getTelefono());
                preparedStatement.setDate(7, new java.sql.Date(persona.getFechaNacimiento().getTime()));
                preparedStatement.setString(8, persona.getSexo());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    @Override
    public void editarPersona(int id, Persona persona) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "UPDATE persona SET t_documento=?, n_documento=?, nombres=?, apellidos=?, " +
                         "direccion=?, telefono=?, f_nacimiento=?, sexo=? WHERE id=?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, persona.getTipoDocumento());
                preparedStatement.setInt(2, persona.getNumeroDocumento());
                preparedStatement.setString(3, persona.getNombres());
                preparedStatement.setString(4, persona.getApellidos());
                preparedStatement.setString(5, persona.getDireccion());
                preparedStatement.setInt(6, persona.getTelefono());
                preparedStatement.setDate(7, new java.sql.Date(persona.getFechaNacimiento().getTime()));
                preparedStatement.setString(8, persona.getSexo());
                preparedStatement.setInt(9, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }


    @Override
    public void eliminarPersona(int id) {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "DELETE FROM persona WHERE id=?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }
    
}
