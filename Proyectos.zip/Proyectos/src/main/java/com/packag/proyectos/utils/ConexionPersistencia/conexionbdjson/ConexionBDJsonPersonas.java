package com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson;

import com.packag.proyectos.models.Persona;



public class ConexionBDJsonPersonas extends ConexionBDJsonBase<Persona> {

    private static ConexionBDJsonPersonas conexionPersonas;

    private ConexionBDJsonPersonas() {
        super("Personas.json");
    }

    public static ConexionBDJsonPersonas getConexion() {
        if (conexionPersonas != null) {
            return conexionPersonas;
        } else {
            conexionPersonas = new ConexionBDJsonPersonas();
            return conexionPersonas;
        }
    }
    
}