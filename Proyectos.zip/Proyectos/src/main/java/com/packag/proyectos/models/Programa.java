package com.packag.proyectos.models;


public class Programa {
    private int id;
    private String nombre;
    private String nivel;
    
    
    public Programa() {
    }

    public Programa(int id, String nombre, String nivel) {
        this.id = id;
        this.nombre = nombre;
        this.nivel = nivel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

   
    
public void imprimir() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Nivel: " + nivel);
    }

}


