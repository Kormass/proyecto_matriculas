package com.packag.proyectos.views;



import com.packag.proyectos.Services.ServiceAlumno;
import com.packag.proyectos.Services.ServiceImpl.ServiceAlumnoImpl;
import com.packag.proyectos.Services.ServiceImpl.ServicePersonaImpl;
import com.packag.proyectos.Services.ServiceImpl.ServiceProfesorImpl;
import com.packag.proyectos.Services.ServicePersona;
import com.packag.proyectos.Services.ServiceProfesor;
import com.packag.proyectos.repository.PersonaRepository;
import com.packag.proyectos.repository.RepositoryImpl.AlumnoImpl;
import com.packag.proyectos.repository.RepositoryImpl.PersonaImpl;
import com.packag.proyectos.repository.RepositoryImpl.ProfesorImpl;
import java.util.Scanner;


public class ViewMain {

 
   public static final ServicePersona servicePersona = new ServicePersonaImpl(new PersonaImpl());    
    public static final ServiceProfesor serviceProfesor = new ServiceProfesorImpl(new ProfesorImpl());
    public static final ServiceAlumno serviceAlumno = new ServiceAlumnoImpl(new AlumnoImpl());
    public static final Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {      
        int op = 0;

        do {

            op = menuMain();
            switch (op) {
                case 1 -> ViewPersona.startMenu();
                case 2 -> ViewAlumno.startMenu();
                case 3 -> ViewProfesor.startMenu();
                default -> System.out.println("Fin");
            }

        } while (op >= 1 && op < 4);

    }

    public static int menuMain() {
        System.out.println("---Aplicación de Profesorción-----");
        System.out.println("1. Modulo de Persona");
        System.out.println("2. Modulo de Alumno");
        System.out.println("3. Modulo de Profesor");
        System.out.println("4. Salir:");
        return leer.nextInt();
    }
}