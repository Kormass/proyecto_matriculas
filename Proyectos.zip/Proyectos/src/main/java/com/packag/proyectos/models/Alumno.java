package com.packag.proyectos.models;


public class Alumno {
    private Persona persona;
    private int id;

   

    // Constructor con la persona
    public Alumno(Persona persona, int id) {
        this.persona = persona;
        this.id = id;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    

    public void imprimir() {
        persona.imprimir();
    }
}
