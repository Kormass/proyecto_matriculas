/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Salon;
import java.util.List;

public interface SalonesRepository {
    List<Salon> listarSalones();
    Salon obtenerSalonPorId(int id);
    void crearSalon(Salon salon);
    void editarSalon(int id, Salon salon);
    void eliminarSalon(int id);
}