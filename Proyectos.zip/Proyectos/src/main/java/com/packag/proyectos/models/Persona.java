package com.packag.proyectos.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Persona {
    private String tipoDocumento;
    private int numeroDocumento;
    private String nombres;
    private String apellidos;
    private String direccion;
    private int telefono;
    private Date fechaNacimiento;
    private String sexo;

    // Constructor con todos los campos
    public Persona(String tipoDocumento, int numeroDocumento, String nombres, String apellidos, String direccion, int telefono, Date fechaNacimiento, String sexo) {
   
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.telefono = telefono;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
    } 

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public int getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(int numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Persona(String tipoDocumento, int numeroDocumento, String nombres, String apellidos, String ciudadResidencia, String direccion, int telefono, String fechaNacimientoStr, String sexo) throws ParseException {

        // Basic validation
        if (tipoDocumento == null || tipoDocumento.isEmpty() ||
                nombres == null || nombres.isEmpty() ||
                apellidos == null || apellidos.isEmpty() ||
                ciudadResidencia == null || ciudadResidencia.isEmpty() ||
                direccion == null || direccion.isEmpty() ||
                fechaNacimientoStr == null || fechaNacimientoStr.isEmpty() ||
                sexo == null || sexo.isEmpty()) {
            throw new IllegalArgumentException("No puede dejar los valores vacios");
        }

        // Additional validation for numerical values
        if (numeroDocumento <= 0 || telefono <= 0) {
            throw new IllegalArgumentException("Numeric values (numeroDocumento, telefono) must be greater than 0");
        }

        // Parse date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date parsedDate = dateFormat.parse(fechaNacimientoStr);

        // Validate date format
        if (!fechaNacimientoStr.equals(dateFormat.format(parsedDate))) {
            throw new IllegalArgumentException("Invalid date format. Please use yyyy-MM-dd");
        }

  }
     public String getFullName(){
        return this.nombres+" "+this.apellidos;

    }
public String getinfocontact(){
        return getFullName() + " " + this.tipoDocumento + " " + this.numeroDocumento + " " + this.telefono;
}
   
public void imprimir() {
        System.out.println("Documento: " + tipoDocumento + " " + numeroDocumento);
        System.out.println("Nombre: " + nombres + " " + apellidos);
        System.out.println("Dirección: " + direccion);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Fecha de Nacimiento: " + fechaNacimiento);
        System.out.println("Sexo: " + sexo);
    }

}