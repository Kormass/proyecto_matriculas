package com.packag.proyectos.repository.RepositoryImpl;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.packag.proyectos.models.Creditos;
import com.packag.proyectos.repository.CreditosRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public class CreditosImpl implements CreditosRepository{

       @Override
       public List<Creditos> listarCreditos() {
           List<Creditos> listaCreditos = new ArrayList<>();

           try (Connection connection = ConexionBDMysql.getInstance()) {
               String sql = "SELECT * FROM creditos";
               try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                   try (ResultSet resultSet = preparedStatement.executeQuery()) {
                       while (resultSet.next()) {
                           double valorCredito = resultSet.getDouble("valorcredito");
                           Creditos creditos = new Creditos(valorCredito);
                           listaCreditos.add(creditos);
                       }
                   }
               }
           } catch (SQLException ex) {
               ex.printStackTrace();
           }

           return listaCreditos;
       }

    @Override
    public Creditos obtenerCreditosPorId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void crearCreditos(Creditos Creditos) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void editarCreditos(int id, Creditos Creditos) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminarCreditos(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
