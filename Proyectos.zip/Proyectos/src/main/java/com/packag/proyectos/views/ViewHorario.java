package com.packag.proyectos.views;

import com.packag.proyectos.models.Horario;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import static com.packag.proyectos.views.ViewMain.serviceHorario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ViewHorario {

    private static final Scanner leer = new Scanner(System.in);

    public static void startMenu() {
        int opcion;
        do {
            System.out.println("------------------------------------------------");
            System.out.println("                  Menú de Horarios               ");
            System.out.println("------------------------------------------------");
            System.out.println("1. Listar Horarios");
            System.out.println("2. Crear Horario");
            System.out.println("3. Modificar Horario");
            System.out.println("4. Eliminar Horario");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción (1-5): ");

            opcion = obtenerOpcion();

            switch (opcion) {
                case 1:
                    listarHorarios();
                    break;
                case 2:
                    crearHorario();
                    break;
                case 3:
                int idModificar = obtenerIdHorario(); // Implementa obtenerIdHorario según tus necesidades
                Horario horarioModificado = obtenerHorarioDesdeUsuario(); // Implementa obtenerHorarioDesdeUsuario según tus necesidades
                modificarHorario(idModificar, horarioModificado);
                break;
                case 4:
                    eliminarHorario();
                    break;
                case 5:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 5);
    }
    private static Horario obtenerHorarioDesdeUsuario() {
    System.out.print("Ingrese el día del horario: ");
    String dia = leer.next();

    System.out.print("Ingrese la hora de inicio del horario (HH:mm:ss): ");
    String horaInicioStr = leer.next();
    java.sql.Time horaInicio = java.sql.Time.valueOf(horaInicioStr);

    System.out.print("Ingrese la hora de fin del horario (HH:mm:ss): ");
    String horaFinStr = leer.next();
    java.sql.Time horaFin = java.sql.Time.valueOf(horaFinStr);

    return new Horario(0, dia, horaInicio, horaFin); // Ajusta el constructor según tu clase Horario
}

    private static int obtenerOpcion() {
        while (!leer.hasNextInt()) {
            System.out.println("Ingrese un número válido.");
            leer.next(); // Limpiar el búfer
        }
        return leer.nextInt();
    }
private static int obtenerIdHorario() {
    System.out.print("Ingrese el ID del horario a modificar: ");
    while (!leer.hasNextInt()) {
        System.out.println("Ingrese un número válido.");
        leer.next(); // Limpiar el búfer
    }
    return leer.nextInt();
}
    private static void listarHorarios() {
    List<Horario> listaHorarios = serviceHorario.listarHorarios();

    System.out.println("Lista de Horarios:\n");

    if (listaHorarios.isEmpty()) {
        System.out.println("No hay horarios registrados.");
    } else {
        for (Horario horario : listaHorarios) {
             System.out.println("----------------------------------------");
            System.out.println("ID: " + horario.getId());
            System.out.println("Día: " + horario.getDia());
            System.out.println("Hora de Inicio: " + horario.getHoraInicio());
            System.out.println("Hora de Fin: " + horario.getHoraFin());
            System.out.println("----------------------------------------");
        }
    }
}


        private static void crearHorario() {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            System.out.print("Ingrese el día del nuevo horario: ");
            String dia = leer.next();

            System.out.print("Ingrese la hora de inicio del nuevo horario (HH:mm:ss): ");
            String horaInicioStr = leer.next();
            java.sql.Time horaInicio = java.sql.Time.valueOf(horaInicioStr);

            System.out.print("Ingrese la hora de fin del nuevo horario (HH:mm:ss): ");
            String horaFinStr = leer.next();
            java.sql.Time horaFin = java.sql.Time.valueOf(horaFinStr);

            String sql = "INSERT INTO horarios (dia, hora_inicio, hora_fin) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, dia);
                preparedStatement.setTime(2, horaInicio);
                preparedStatement.setTime(3, horaFin);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Maneja la excepción según tus necesidades
        }
    }


private static void modificarHorario(int id, Horario horario) {
    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "UPDATE horarios SET dia = ?, hora_inicio = ?, hora_fin = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, horario.getDia());
            preparedStatement.setTime(2, new java.sql.Time(horario.getHoraInicio().getTime()));
            preparedStatement.setTime(3, new java.sql.Time(horario.getHoraFin().getTime()));
            preparedStatement.setInt(4, id);

            preparedStatement.executeUpdate();
        }
        System.out.println("Horario modificado correctamente.");
    } catch (SQLException e) {
        e.printStackTrace(); // Maneja la excepción según tus necesidades
    }
}


   private static void eliminarHorario() {
    System.out.print("Ingrese el ID del horario que desea eliminar: ");
    int id = obtenerOpcion();

    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "DELETE FROM horarios WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);

            int filasEliminadas = preparedStatement.executeUpdate();
            if (filasEliminadas > 0) {
                System.out.println("Horario eliminado correctamente.");
            } else {
                System.out.println("No se encontró el horario con el ID proporcionado.");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Maneja la excepción según tus necesidades
    }
}

  } 
