package com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson;

import com.packag.proyectos.models.Alumno;



public class ConexionBDJsonAlumnos extends ConexionBDJsonBase<Alumno> {

    private static ConexionBDJsonAlumnos conexionAlumnos;

    private ConexionBDJsonAlumnos() {
        super("Alumnos.json");
    }

    public static ConexionBDJsonAlumnos getConexion() {
        if (conexionAlumnos != null) {
            return conexionAlumnos;
        } else {
            conexionAlumnos = new ConexionBDJsonAlumnos();
            return conexionAlumnos;
        }
    }
    
}
