/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;


public class Creditos {
    private double valorCredito;

    public Creditos(double valorCredito) {
        this.valorCredito = valorCredito;
    }

    public double getValorCredito() {
        return valorCredito;
    }

    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }

    public void imprimir() {
        System.out.println("Valor por Asignatura: " + valorCredito);
    }
}
