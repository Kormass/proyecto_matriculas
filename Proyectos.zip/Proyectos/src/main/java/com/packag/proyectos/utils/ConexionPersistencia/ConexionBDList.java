package com.packag.proyectos.utils.ConexionPersistencia;

import java.util.ArrayList;
import java.util.List;
import com.packag.proyectos.models.Alumno;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.models.Profesor;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import lombok.Data;

@Data
public class ConexionBDList {

    private static ConexionBDList conexion;
    private List<Alumno> listaAlumnos; // Cambié listaClientes por listaAlumnos
    private List<Persona> listaPersonas; // Cambié listaProductos por listaPersonas
    private List<Profesor> listaProfesores; // Cambié listFacturas por listaProfesores

    private ConexionBDList() throws ParseException {
        listaAlumnos = new ArrayList<>();
        listaPersonas = new ArrayList<>();
        listaProfesores = new ArrayList<>();
        this.loadData();
    }

    public static ConexionBDList getConexion() throws ParseException {
        if (conexion != null) {
            return conexion;
        } else {
            conexion = new ConexionBDList();
            return conexion;
        }
    }

    private void loadData() throws ParseException {
        getLoadDataAlumnos(); // Cambié getLoadDataClientes por getLoadDataAlumnos
        getLoadDataProfesores(); // Cambié getLoadDataFactura por getLoadDataProfesores
        getLoadDataPersonas(); // Cambié getLoadDataProductos por getLoadDataPersonas
    }

        private void getLoadDataAlumnos() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    try {
        Persona persona1 = new Persona(1,"DNI", 12345678, "Pedro", "Ortega", "Cra 3", 123456789, dateFormat.parse("1990-01-15"), "Masculino");
        Persona persona2 = new Persona(2,"DNI", 23456789, "María", "Gómez", "Av 5", 987654321, dateFormat.parse("1995-03-20"), "Femenino");
        Persona persona3 = new Persona(3,"CED", 34567890, "Andrés", "Sarmiento", "Calle 7", 876543210, dateFormat.parse("1988-07-10"), "Masculino");
        Persona persona4 = new Persona(4,"CED", 45678901, "Lizeth", "Villamizar", "Cra 8", 765432109, dateFormat.parse("1992-12-05"), "Femenino");
        Persona persona5 = new Persona(5,"DNI", 56789012, "Gladys", "Moreno", "Av 9", 654321098, dateFormat.parse("1987-09-30"), "Femenino");
        Persona persona6 = new Persona(6,"DNI", 67890123, "Sebastian", "Dominguez", "Cra 10", 543210987, dateFormat.parse("1998-05-22"), "Masculino");
        Persona persona7 = new Persona(7,"CED", 78901234, "Maura", "Sabolla", "Calle 11", 432109876, dateFormat.parse("1993-11-18"), "Femenino");
        Persona persona8 = new Persona(8,"CED", 89012345, "Catalina", "Moreno", "Av 12", 321098765, dateFormat.parse("1996-04-14"), "Femenino");
        Persona persona9 = new Persona(9,"DNI", 90123456, "Celina", "Torres", "Cra 13", 210987654, dateFormat.parse("1991-08-25"), "Femenino");
        Persona persona10 = new Persona(10,"CED", 12345678, "Diego", "Rangel", "Calle 14", 109876543, dateFormat.parse("1989-02-08"), "Masculino");

        // Agregar instancias de Alumno a listaAlumnos
        listaAlumnos.add(new Alumno(persona1, 1));
        listaAlumnos.add(new Alumno(persona2, 2));
        listaAlumnos.add(new Alumno(persona3, 3));
        listaAlumnos.add(new Alumno(persona4, 4));
        listaAlumnos.add(new Alumno(persona5, 5));
        listaAlumnos.add(new Alumno(persona6, 6));
        listaAlumnos.add(new Alumno(persona7, 7));
        listaAlumnos.add(new Alumno(persona8, 8));
        listaAlumnos.add(new Alumno(persona9, 9));
        listaAlumnos.add(new Alumno(persona10, 10));

    } catch (ParseException e) {
        e.printStackTrace();
    }
}



    private void getLoadDataPersonas() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    try {
        Persona persona1 = new Persona(11,"DNI", 12345678, "Juana", "Perez", "dirección", 123456789, dateFormat.parse("1995-02-10"), "Femenino");
        Persona persona2 = new Persona(12,"CED", 23456789, "Maria", "Gomez", "dirección", 987654321, dateFormat.parse("1990-08-15"), "Femenino");
        Persona persona3 = new Persona(13,"DNI", 34567890, "Andres", "Sarmiento", "dirección", 876543210, dateFormat.parse("1988-05-22"), "Masculino");
        Persona persona4 = new Persona(14,"CED", 45678901, "Lizeth", "Villamizar", "dirección", 765432109, dateFormat.parse("1993-11-18"), "Femenino");
        Persona persona5 = new Persona(15,"DNI", 56789012, "Gladys", "Moreno", "dirección", 654321098, dateFormat.parse("1996-04-14"), "Femenino");
        Persona persona6 = new Persona(16,"CED", 67890123, "Sebastian", "Dominguez", "dirección", 543210987, dateFormat.parse("1991-08-25"), "Masculino");
        Persona persona7 = new Persona(17,"DNI", 78901234, "Maura", "Sabolla", "dirección", 432109876, dateFormat.parse("1998-03-30"), "Femenino");
        Persona persona8 = new Persona(18,"CED", 89012345, "Catalina", "Moreno", "dirección", 321098765, dateFormat.parse("1987-09-05"), "Femenino");
        Persona persona9 = new Persona(19,"DNI", 90123456, "Celina", "Torres", "dirección", 210987654, dateFormat.parse("1994-07-12"), "Femenino");
        Persona persona10 = new Persona(20,"CED", 12345678, "Diego", "Rangel", "dirección", 109876543, dateFormat.parse("1997-01-28"), "Masculino");

        // Agregar instancias de Persona a listaPersonas
        listaPersonas.add(persona1);
        listaPersonas.add(persona2);
        listaPersonas.add(persona3);
        listaPersonas.add(persona4);
        listaPersonas.add(persona5);
        listaPersonas.add(persona6);
        listaPersonas.add(persona7);
        listaPersonas.add(persona8);
        listaPersonas.add(persona9);
        listaPersonas.add(persona10);

    } catch (ParseException e) {
        e.printStackTrace();
    }
}


    private void getLoadDataProfesores() throws ParseException {
    // Crear instancias de Persona para cada Profesor
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
  // Ejemplos adicionales de Personas para Alumnos
    Persona persona1 = new Persona(11,"DNI", 12345678, "Juana", "Perez", "dirección", 123456789, dateFormat.parse("1995-02-10"), "Femenino");
        Persona persona2 = new Persona(12,"CED", 23456789, "Maria", "Gomez", "dirección", 987654321, dateFormat.parse("1990-08-15"), "Femenino");
        Persona persona3 = new Persona(13,"DNI", 34567890, "Andres", "Sarmiento", "dirección", 876543210, dateFormat.parse("1988-05-22"), "Masculino");
        Persona persona4 = new Persona(14,"CED", 45678901, "Lizeth", "Villamizar", "dirección", 765432109, dateFormat.parse("1993-11-18"), "Femenino");
        Persona persona5 = new Persona(15,"DNI", 56789012, "Gladys", "Moreno", "dirección", 654321098, dateFormat.parse("1996-04-14"), "Femenino");
        Persona persona6 = new Persona(16,"CED", 67890123, "Sebastian", "Dominguez", "dirección", 543210987, dateFormat.parse("1991-08-25"), "Masculino");
        Persona persona7 = new Persona(17,"DNI", 78901234, "Maura", "Sabolla", "dirección", 432109876, dateFormat.parse("1998-03-30"), "Femenino");
        Persona persona8 = new Persona(18,"CED", 89012345, "Catalina", "Moreno", "dirección", 321098765, dateFormat.parse("1987-09-05"), "Femenino");
        Persona persona9 = new Persona(19,"DNI", 90123456, "Celina", "Torres", "dirección", 210987654, dateFormat.parse("1994-07-12"), "Femenino");
        Persona persona10 = new Persona(20,"CED", 12345678, "Diego", "Rangel", "dirección", 109876543, dateFormat.parse("1997-01-28"), "Masculino");

    // Crear instancias de Profesor utilizando las instancias de Persona
    Profesor profesor1 = new Profesor(1, persona1, 101);
    Profesor profesor2 = new Profesor(2, persona2, 102);
    Profesor profesor3 = new Profesor(3, persona3, 103);
    Profesor profesor4 = new Profesor(4, persona4, 104);
    Profesor profesor5 = new Profesor(5, persona5, 105);
    Profesor profesor6 = new Profesor(6, persona6, 106);
    Profesor profesor7 = new Profesor(7, persona7, 107);
    Profesor profesor8 = new Profesor(8, persona8, 108);
    Profesor profesor9 = new Profesor(9, persona9, 109);
    Profesor profesor10 = new Profesor(10, persona10, 110);

    // Agregar instancias de Profesor a listaProfesores
    listaProfesores.add(profesor1);
    listaProfesores.add(profesor2);
    listaProfesores.add(profesor3);
    listaProfesores.add(profesor4);
    listaProfesores.add(profesor5);
    listaProfesores.add(profesor6);
    listaProfesores.add(profesor7);
    listaProfesores.add(profesor8);
    listaProfesores.add(profesor9);
    listaProfesores.add(profesor10);
}



    // Resto de tu código...
}
