package com.packag.proyectos.Services.ServiceImpl;


import com.packag.proyectos.Services.ServiceHorario;
import com.packag.proyectos.models.Horario;
import java.util.List;

public class ServiceHorarioImpl implements ServiceHorario {
    private final HorarioRepository crudRepositoryHorario;

    public ServiceHorarioImpl(HorarioRepository crudRepositoryHorario) {
        this.crudRepositoryHorario = crudRepositoryHorario;
    }

    @Override
    public List<Horario> listarHorarios() {
        return crudRepositoryHorario.listarHorarios();
    }

    @Override
    public Horario obtenerHorarioPorId(int id) {
        return crudRepositoryHorario.obtenerHorarioPorId(id);
    }

    @Override
    public void crearHorario(Horario horario) {
        crudRepositoryHorario.crearHorario(horario);
    }

    @Override
    public void editarHorario(int id, Horario horario) {
        crudRepositoryHorario.editarHorario(id, horario);
    }

    @Override
    public void eliminarHorario(int id) {
        crudRepositoryHorario.eliminarHorario(id);
    }
}
