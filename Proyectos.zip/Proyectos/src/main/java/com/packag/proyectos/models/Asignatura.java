/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;

public class Asignatura {
    private int id;
    private Profesor profesor;
    private Periodo periodo;
    private Programa programa;
    private String nombre;
    private Creditos creditos;
    private String lugaresDisponibles;
    private Horario horario;
    private Salon salon;

    public Asignatura(int id, Profesor profesor, Periodo periodo, Programa programa, String nombre, Creditos creditos, String lugaresDisponibles, Horario horario, Salon salon) {
       this.id = id;
        this.profesor = profesor;
        this.periodo = periodo;
        this.programa = programa;
        this.nombre = nombre;
        this.creditos = creditos;
        this.lugaresDisponibles = lugaresDisponibles;
        this.horario = horario;
        this.salon = salon;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    


    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Periodo getPeriodo() {
        return periodo;
    }

    public void setPeriodo(Periodo periodo) {
        this.periodo = periodo;
    }

    public Programa getPrograma() {
        return programa;
    }

    public void setPrograma(Programa programa) {
        this.programa = programa;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Creditos getCreditos() {
        return creditos;
    }

    public void setCreditos(Creditos creditos) {
        this.creditos = creditos;
    }

    public String getLugaresDisponibles() {
        return lugaresDisponibles;
    }

    public void setLugaresDisponibles(String lugaresDisponibles) {
        this.lugaresDisponibles = lugaresDisponibles;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }

    public Salon getSalon() {
        return salon;
    }

    public void setSalon(Salon salon) {
        this.salon = salon;
    }

    
    public void imprimir() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Profesor: ");
        profesor.imprimir();
        System.out.println("Periodo: ");
        periodo.imprimir();
        System.out.println("Programa: ");
        programa.imprimir();
        System.out.println("Créditos: ");
        creditos.imprimir();
        System.out.println("Lugares Disponibles: " + lugaresDisponibles);
        System.out.println("Horario: ");
        horario.imprimir();
        System.out.println("Salón: ");
        salon.imprimir();
    }
}