package com.packag.proyectos.views;



import com.packag.proyectos.Services.ServicePeriodo;
import com.packag.proyectos.Services.ServiceAlumno;
import com.packag.proyectos.Services.ServiceHorario;
import com.packag.proyectos.Services.ServiceImpl.ServiceAlumnoImpl;
import com.packag.proyectos.Services.ServiceImpl.ServiceHorarioImpl;
import com.packag.proyectos.Services.ServiceImpl.ServicePeriodoImpl;
import com.packag.proyectos.Services.ServiceImpl.ServicePersonaImpl;
import com.packag.proyectos.Services.ServiceImpl.ServiceProfesorImpl;
import com.packag.proyectos.Services.ServicePersona;
import com.packag.proyectos.Services.ServiceProfesor;
import com.packag.proyectos.repository.RepositoryImpl.AlumnoImpl;
import com.packag.proyectos.repository.RepositoryImpl.HorarioImpl;
import com.packag.proyectos.repository.RepositoryImpl.PeriodoImpl;
import com.packag.proyectos.repository.RepositoryImpl.PersonaImpl;
import com.packag.proyectos.repository.RepositoryImpl.ProfesorImpl;
import java.util.Scanner;

public class ViewMain {
    public static final ServiceHorario serviceHorario = new ServiceHorarioImpl(new HorarioImpl());
    public static final ServicePersona servicePersona = new ServicePersonaImpl(new PersonaImpl());
    public static final ServiceProfesor serviceProfesor = new ServiceProfesorImpl(new ProfesorImpl());
    public static final ServiceAlumno serviceAlumno = new ServiceAlumnoImpl(new AlumnoImpl());
    public static final Scanner leer = new Scanner(System.in);
    public static final ServicePeriodo servicePeriodo = new ServicePeriodoImpl(new PeriodoImpl());
    public static void main(String[] args) {
        int op = 0;

        do {
            op = menuMain();
            switch (op) {
                case 1 -> ViewPersona.startMenu();
                case 2 -> ViewAlumno.startMenu();
                case 3 -> ViewProfesor.startMenu();
                case 4 -> ViewMatricula.startMenu();
                case 5 -> ViewPeriodo.startMenu();
                case 6 -> ViewHorario.startMenu();// Nuevo caso para el módulo de Matrícula

                default -> System.out.println("Fin");
            }

        } while (op >= 1 && op < 5); // Ajusta la condición para incluir el nuevo caso

    }

    public static int menuMain() {
    System.out.println("===============================================");
    System.out.println("          Aplicación de Modulos");
    System.out.println("===============================================");
    System.out.println("1. Modulo de Personas");
    System.out.println("2. Modulo de Alumnos");
    System.out.println("3. Modulo de Profesores");
    System.out.println("4. Modulo de Matrículas");
    System.out.println("5. Modulo de Periodos");
    System.out.println("6. Modulo de Horaios");
    System.out.println("6. Salir");
    System.out.println("===============================================");
    System.out.print("Ingrese su opción: ");
    return leer.nextInt();
}
    }
