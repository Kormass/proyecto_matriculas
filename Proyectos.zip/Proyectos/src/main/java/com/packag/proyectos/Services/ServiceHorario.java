/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services;

import com.packag.proyectos.models.Horario;
import java.util.List;


public interface ServiceHorario {
    List<Horario> listarHorarios();
    Horario obtenerHorarioPorId(int id);
    void crearHorario(Horario horario);
    void editarHorario(int id, Horario horario);
    void eliminarHorario(int id);
}
