package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.Services.ServiceImpl.HorarioRepository;
import com.packag.proyectos.models.Horario;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson.ConexionBDJsonAlumnos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class HorarioImpl implements HorarioRepository {
    
    @Override
    public List<Horario> listarHorarios() {
        List<Horario> horarios = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM horarios";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    Horario horario = mapResultSetToHorario(resultSet);
                    horarios.add(horario);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return horarios;
    }
        private Horario mapResultSetToHorario(ResultSet resultSet) throws SQLException {
        int id = resultSet.getInt("id");
        String dia = resultSet.getString("dia");
        Time horaInicio = resultSet.getTime("hora_inicio");
        Time horaFin = resultSet.getTime("hora_fin");

        return new Horario(id, dia, horaInicio, horaFin);
    }

       @Override
public Horario obtenerHorarioPorId(int id) {
    try (Connection connection = ConexionBDMysql.getInstance();
         PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM horarios WHERE id = ?")) {

        preparedStatement.setInt(1, id);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return mapResultSetToHorario(resultSet);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }

    return null;
}



    @Override
public void crearHorario(Horario horario) {

    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "INSERT INTO horarios (dia, hora_inicio, hora_fin) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, horario.getDia());
            preparedStatement.setTime(2, new java.sql.Time(horario.getHoraInicio().getTime()));
            preparedStatement.setTime(3, new java.sql.Time(horario.getHoraFin().getTime()));

            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Maneja la excepción según tus necesidades
    }
}





    @Override
public void editarHorario(int id, Horario horario) {

    try (Connection connection = ConexionBDMysql.getInstance()) {
        String sql = "UPDATE horarios SET dia = ?, hora_inicio = ?, hora_fin = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, horario.getDia());
            preparedStatement.setTime(2, new java.sql.Time(horario.getHoraInicio().getTime()));
            preparedStatement.setTime(3, new java.sql.Time(horario.getHoraFin().getTime()));
            preparedStatement.setInt(4, id);

            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Maneja la excepción según tus necesidades
    }
}

   @Override
public void eliminarHorario(int id) {
    try (Connection connection = ConexionBDMysql.getInstance();
         PreparedStatement preparedStatement = connection.prepareStatement(
                 "DELETE FROM horarios WHERE id = ?")) {

        preparedStatement.setInt(1, id);

        preparedStatement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace(); // Maneja la excepción según tus necesidades
    }
}
    }
   
    
