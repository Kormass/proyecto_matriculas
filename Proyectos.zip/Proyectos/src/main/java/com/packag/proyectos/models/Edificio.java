/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.models;


public class Edificio {
    private String piso;
    private int cantidadSalones;

    public Edificio(String piso, int cantidadSalones) {
        this.piso = piso;
        this.cantidadSalones = cantidadSalones;
    }

    public String getPiso() {
        return piso;
    }

    public void setPiso(String piso) {
        this.piso = piso;
    }

    public int getCantidadSalones() {
        return cantidadSalones;
    }

    public void setCantidadSalones(int cantidadSalones) {
        this.cantidadSalones = cantidadSalones;
    }
    

    public void imprimir() {
        System.out.println("Piso: " + piso);
        System.out.println("Cantidad de Salones: " + cantidadSalones);
    }
}
