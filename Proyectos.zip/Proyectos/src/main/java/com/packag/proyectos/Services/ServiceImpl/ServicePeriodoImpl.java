/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services.ServiceImpl;

import com.packag.proyectos.Services.ServicePeriodo;
import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.repository.AlumnoRepository;
import com.packag.proyectos.repository.PeriodoRepository;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.repository.PeriodoRepository;

import java.util.List;

public class ServicePeriodoImpl implements ServicePeriodo {
    private final PeriodoRepository periodoRepository;

    public ServicePeriodoImpl(PeriodoRepository periodoRepository) {
        this.periodoRepository = periodoRepository;
    }

    @Override
    public List<Periodo> listarPeriodos() {
        return periodoRepository.listarPeriodos();
    }

    @Override
    public Periodo obtenerPeriodoPorId(int id) {
        return periodoRepository.obtenerPeriodoPorId(id);
    }

    @Override
    public void crearPeriodo(Periodo periodo) {
        periodoRepository.crearPeriodo(periodo);
    }

    @Override
    public void editarPeriodo(int id, Periodo periodo) {
        periodoRepository.editarPeriodo(id, periodo);
    }

    @Override
    public void eliminarPeriodo(int id) {
        periodoRepository.eliminarPeriodo(id);
    }
}

