/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Persona;
import java.util.List;
public interface PersonaRepository {
    List<Persona> listarPersonas();
    Persona obtenerPersonaPorId(int id);
    List<Persona> obtenerPersonaPorDocumento(int numeroDocumento);
    void crearPersona(Persona persona);
    void editarPersona(int id, Persona persona);
    void eliminarPersona(int id);
}