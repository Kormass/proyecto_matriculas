package com.packag.proyectos.models;




public class Tarifa {
    private Matricula matricula;
    private double valor;

    public Tarifa( Matricula matricula, double valor) {
        this.matricula = matricula;
        this.valor = valor;
    }

    public Matricula getMatricula() {
        return matricula;
    }

    public void setMatricula(Matricula matricula) {
        this.matricula = matricula;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void imprimir() {
        System.out.println("Matrícula: ");
        matricula.imprimir();
        System.out.println("Valor: " + valor);
    }
}
