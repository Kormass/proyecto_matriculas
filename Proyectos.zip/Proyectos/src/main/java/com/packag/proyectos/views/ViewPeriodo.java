package com.packag.proyectos.views;

import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.repository.PeriodoRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import static com.packag.proyectos.views.ViewMain.servicePeriodo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;


public class ViewPeriodo {

    private static final Scanner leer = new Scanner(System.in);

    public static void startMenu() {
        int opcion;

        do {
            System.out.println("---- Menú Periodo ----");
            System.out.println("1. Crear periodo");
            System.out.println("2. Listar periodos");
            System.out.println("3. Buscar periodo por ID");
            System.out.println("4. Modificar periodo");
            System.out.println("5. Eliminar periodo");
            System.out.println("6. Salir");
            System.out.print("Ingrese su opción: ");

            opcion = leer.nextInt();
            leer.nextLine(); // Limpiar el buffer después de leer el entero

            switch (opcion) {
                case 1:
                    crearPeriodo();
                    break;
                case 2:
                    listarPeriodos();
                    break;
                case 3:
                    buscarPeriodoPorId();
                    break;
                case 4:
                    modificarPeriodo();
                    break;
                case 5:
                    eliminarPeriodo();
                    break;
                case 6:
                    System.out.println("Saliendo del menú de Periodo.");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }

        } while (opcion != 6);
    }

    public static void crearPeriodo() {
        try (Connection connection = ConexionBDMysql.getInstance()) {
            // Obtener el código y el semestre desde la entrada del usuario
            System.out.print("Código del periodo: ");
            int codigo = leer.nextInt();

            System.out.print("Semestre del periodo: ");
            int semestre = leer.nextInt();

            // Obtener la fecha del periodo desde la entrada del usuario
            System.out.print("Fecha del periodo (YYYY-MM-DD): ");
            String fechaStr = leer.next();
            Date ano = convertirStringADate(fechaStr);

            // SQL query para insertar un nuevo periodo
            String sql = "INSERT INTO periodo (codigo, ano, semestre) VALUES (?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, codigo);
                preparedStatement.setDate(2, ano);
                preparedStatement.setInt(3, semestre);

                // Ejecutar la consulta
                int filasAfectadas = preparedStatement.executeUpdate();

                if (filasAfectadas > 0) {
                    System.out.println("Periodo creado exitosamente.");
                } else {
                    System.out.println("Error al crear el periodo.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Date convertirStringADate(String fechaStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fechaUtil = sdf.parse(fechaStr);
            return new Date(fechaUtil.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }


    private static void listarPeriodos() {
    System.out.println("Lista de Periodos");

    // Obtén la lista de periodos desde la base de datos usando tu servicio correspondiente
    List<Periodo> listaPeriodos = servicePeriodo.listarPeriodos();

    if (listaPeriodos.isEmpty()) {
        System.out.println("No hay periodos registrados.");
    } else {
        for (Periodo periodo : listaPeriodos) {
            if (periodo != null) {
                periodo.imprimir();  // Puedes crear un método imprimir en la clase Periodo
                System.out.println();
            } else {
                System.out.println("Error: Periodo es null en la lista.");
            }
        }
    }
}


    private static void buscarPeriodoPorId() {
        // Implementa la lógica para buscar un periodo por ID
        // Puedes utilizar un servicio similar a servicePersona para obtener el periodo desde la base de datos
    }

    private static void modificarPeriodo() {
        // Implementa la lógica para modificar un periodo
        // Puedes utilizar un servicio similar a servicePersona para editar el periodo en la base de datos
    }

    private static void eliminarPeriodo() {
        // Implementa la lógica para eliminar un periodo
        // Puedes utilizar un servicio similar a servicePersona para eliminar el periodo de la base de datos
    }
}
