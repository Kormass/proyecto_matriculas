/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services;

/**
 *
 * @author Jefferson Jair
 */
import com.packag.proyectos.models.Periodo;
import com.packag.proyectos.repository.PeriodoRepository;

import java.util.List;

public interface ServicePeriodo {
    List<Periodo> listarPeriodos();

    Periodo obtenerPeriodoPorId(int id);

    void crearPeriodo(Periodo periodo);

    void editarPeriodo(int id, Periodo periodo);

    void eliminarPeriodo(int id);
}
