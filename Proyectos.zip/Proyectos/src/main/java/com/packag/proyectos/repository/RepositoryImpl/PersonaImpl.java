package com.packag.proyectos.repository.RepositoryImpl;

import com.packag.proyectos.models.Persona;
import com.packag.proyectos.repository.PersonaRepository;
import com.packag.proyectos.utils.ConexionPersistencia.Conexionbdmysql.ConexionBDMysql;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PersonaImpl implements PersonaRepository {
    
    @Override
    public List<Persona> listarPersonas() {
        // Implementación para obtener la lista de personas desde la base de datos
        List<Persona> personas = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM persona";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    // Mapear los datos de la base de datos a objetos Persona
                    Persona persona = mapResultSetToPersona(resultSet);
                    personas.add(persona);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return personas;
    }

    @Override
    public Persona obtenerPersonaPorId(int id) {
        // Implementación para obtener una persona por ID desde la base de datos
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM persona WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return mapResultSetToPersona(resultSet);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<Persona> obtenerPersonaPorDocumento(int numeroDocumento) {
        // Implementación para obtener personas por número de documento desde la base de datos
        List<Persona> personas = new ArrayList<>();

        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "SELECT * FROM persona WHERE n_Documento = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, numeroDocumento);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Persona persona = mapResultSetToPersona(resultSet);
                        personas.add(persona);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return personas;
    }

    @Override
    public void crearPersona(Persona persona) {
        // Implementación para insertar una nueva persona en la base de datos
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "INSERT INTO persona (t_documento, n_Documento, nombres, apellidos, direccion, telefono, f_nacimiento, sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, persona.getTipoDocumento());
                preparedStatement.setInt(2, persona.getNumeroDocumento());
                preparedStatement.setString(3, persona.getNombres());
                preparedStatement.setString(4, persona.getApellidos());
                preparedStatement.setString(5, persona.getDireccion());
                preparedStatement.setInt(6, persona.getTelefono());
                preparedStatement.setDate(7, new java.sql.Date(persona.getFechaNacimiento().getTime()));
                preparedStatement.setString(8, persona.getSexo());

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void editarPersona(int id, Persona persona) {
        // Implementación para editar una persona en la base de datos
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "UPDATE persona SET t_documento = ?, n_Documento = ?, nombres = ?, apellidos = ?, direccion = ?, telefono = ?, f_nacimiento = ?, sexo = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, persona.getTipoDocumento());
                preparedStatement.setInt(2, persona.getNumeroDocumento());
                preparedStatement.setString(3, persona.getNombres());
                preparedStatement.setString(4, persona.getApellidos());
                preparedStatement.setString(5, persona.getDireccion());
                preparedStatement.setInt(6, persona.getTelefono());
                preparedStatement.setDate(7, new java.sql.Date(persona.getFechaNacimiento().getTime()));
                preparedStatement.setString(8, persona.getSexo());
                preparedStatement.setInt(9, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminarPersona(int id) {
        // Implementación para eliminar una persona de la base de datos
        try (Connection connection = ConexionBDMysql.getInstance()) {
            String sql = "DELETE FROM persona WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, id);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Persona mapResultSetToPersona(ResultSet resultSet) throws SQLException {
    int id = resultSet.getInt("id");
    String tipoDocumento = resultSet.getString("t_documento");
    int numeroDocumento = resultSet.getInt("n_documento");
    String nombres = resultSet.getString("nombres");
    String apellidos = resultSet.getString("apellidos");
    String direccion = resultSet.getString("direccion");
    int telefono = resultSet.getInt("telefono");
    Date fechaNacimiento = resultSet.getDate("f_nacimiento");
    String sexo = resultSet.getString("sexo");

    // Crear y devolver un objeto Persona con los datos mapeados
    return new Persona(id, tipoDocumento, numeroDocumento, nombres, apellidos, direccion, telefono, fechaNacimiento, sexo);
}

}
