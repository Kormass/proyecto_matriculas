package com.packag.proyectos.utils.ConexionPersistencia.conexionbdjson;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.packag.proyectos.models.Alumno;
import com.packag.proyectos.models.Persona;
import com.packag.proyectos.models.Profesor;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ConexionBDJson  {

    private static ConexionBDJson conexion;
    private List<Alumno> listaAlumno;
    private List<Profesor> listaProfesor;
    private List<Persona> listPersona;

    private ConexionBDJson() {
        listaAlumno = new ArrayList<>();
        listaProfesor = new ArrayList<>();
        listPersona = new ArrayList<>();
       
    }

    public static ConexionBDJson getConexion() {
        if (conexion != null) {
            return conexion;
        } else {
            conexion = new ConexionBDJson();
            return conexion;
        }
    }

    

    public List<Alumno> getDataAlumnos() {
        ObjectMapper objectMapper=new ObjectMapper();            
            try{
                listaAlumno=objectMapper.readValue(new File("Alumnos.json"), new TypeReference<List<Alumno>>(){});
            }catch(IOException e){
               e.printStackTrace();
            }
            return listaAlumno;
    }
    public void saveDataAlumnos(List<Alumno> listAlumnosUpdate){
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

        try {
            objectMapper.writeValue(new File("Alumnos.json"), listAlumnosUpdate);
            System.out.println("Se guardo los Alumnos en Alumno.json");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    

    

}
