
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Programa;
import java.util.List;

public interface ProgramasRepository {
    List<Programa> listarProgramas();
    Programa obtenerProgramaPorId(int id);
    void crearPrograma(Programa programa);
    void editarPrograma(int id, Programa programa);
    void eliminarPrograma(int id);
}
