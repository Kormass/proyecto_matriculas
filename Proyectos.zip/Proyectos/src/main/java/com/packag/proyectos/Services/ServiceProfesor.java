/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services;

import com.packag.proyectos.models.Profesor;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public interface ServiceProfesor {
    List<Profesor> listarProfesores();
    Profesor obtenerProfesorPorDocumento(int numeroDocumento);
    void crearProfesor(Profesor nuevoProfesor);
    void actualizarProfesor(Profesor profesorActualizado);
    void eliminarProfesor(int idProfesor);

}
    
