/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Alumno;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */

    public interface AlumnoRepository {

    List<Alumno> listar();
    Alumno porId(int id);
    Alumno porDocumento(String documento);

    void crear(Alumno alumno);

    void editar(Alumno alumno);

    void eliminar(Alumno alumno);

}