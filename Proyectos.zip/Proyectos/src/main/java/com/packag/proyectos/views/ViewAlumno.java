/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.views;

import com.packag.proyectos.Services.ServiceAlumno;
import com.packag.proyectos.models.Alumno;
import com.packag.proyectos.models.Persona;
import java.sql.Date;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;




public class ViewAlumno extends ViewMain {
    
    

    private static final Scanner scanner = new Scanner(System.in);

    public static void startMenu() {
        int op = 0;

        do {
            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearAlumno();
                    break;
                case 2:
                    listarAlumnos();
                    break;
                case 3:
                    buscarAlumno();
                    break;
                case 4:
                    modificarAlumno();
                    break;
                case 5:
                    eliminarAlumno();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);
    }

            public static int mostrarMenu() {
            System.out.println("===============================================");
            System.out.println("              Menú de Alumnos");
            System.out.println("===============================================");
            System.out.println("1. Crear Alumno");
            System.out.println("2. Listar Alumnos");
            System.out.println("3. Buscar Alumno");
            System.out.println("4. Modificar Alumno");
            System.out.println("5. Eliminar Alumno");
            System.out.println("0. Salir");
            System.out.print("Ingrese su opción: ");

            return scanner.nextInt();
        }


    public static void buscarAlumnos() {
        try {
            leer.nextLine();
            System.out.print("Documento: ");
            String documento = leer.nextLine();

            Alumno alumno = serviceAlumno.porDocumento(documento);

            if (alumno != null) {
                System.out.println("Alumno encontrado:");
                alumno.imprimir();

                // Puedes solicitar al usuario que ingrese nuevos datos
                System.out.print("Nuevo nombre: ");
                String nuevoNombre = leer.nextLine();

                System.out.print("Nuevo apellido: ");
                String nuevoApellido = leer.nextLine();

                // Actualizar los datos del alumno
                alumno.getPersona().setNombres(nuevoNombre);
                alumno.getPersona().setApellidos(nuevoApellido);

                // Llamar al servicio para actualizar el alumno en la base de datos
                serviceAlumno.editar(alumno);

                System.out.println("Alumno actualizado correctamente.");
            } else {
                System.out.println("Alumno no encontrado");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese datos válidos.");
            leer.nextLine(); // Limpiar el buffer
        }
    }


public static void listarAlumnos() {
    try {
        List<Alumno> alumnos = serviceAlumno.listar();

        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos registrados.");
        } else {
            System.out.println("Lista de Alumnos:");
            for (Alumno alumno : alumnos) {
                System.out.println("ID: " + alumno.getId() +
                        ", Nombre: " + alumno.getPersona().getNombres() +
                        " " + alumno.getPersona().getApellidos());
            }

            // Submenú para listar por nombre o por ID
            System.out.println("===============================================");
            System.out.println("               Submenú de Listado");
            System.out.println("===============================================");
            System.out.println("1. Listar por Nombre");
            System.out.println("2. Listar por ID");
            System.out.println("===============================================");
            System.out.print("Ingrese su opción: ");
            
            int opcionSubMenu = leer.nextInt();

            switch (opcionSubMenu) {
                case 1:
                    // Listar por Nombre
                    System.out.println("Listando por Nombre:");
                    // Ordenar la lista por nombre
                    Collections.sort(alumnos, (a1, a2) ->
                            a1.getPersona().getNombres().compareTo(a2.getPersona().getNombres()));
                    break;
                case 2:
                    // Listar por ID
                    System.out.println("Listando por ID:");
                    // Ordenar la lista por ID
                    Collections.sort(alumnos, (a1, a2) -> Integer.compare(a1.getId(), a2.getId()));
                    break;
                default:
                    System.out.println("Opción no válida.");
                    return;
            }

            // Mostrar la lista ordenada
            for (Alumno alumno : alumnos) {
                System.out.println("ID: " + alumno.getId() +
                        ", Nombre: " + alumno.getPersona().getNombres() +
                        " " + alumno.getPersona().getApellidos());
            }
        }
    } catch (InputMismatchException e) {
        System.out.println("Error: Ingrese datos válidos.");
        leer.nextLine(); // Limpiar el buffer
    }
}


    private static void buscarAlumno() {
    System.out.println("===============================================");
    System.out.println("            Búsqueda de Alumno");
    System.out.println("===============================================");

    int opcionBusqueda = menuBusqueda();

    switch (opcionBusqueda) {
        case 1:
            buscarPorDocumento();
            break;
        case 2:
            buscarPorId();
            break;
        default:
            System.out.println("Opción no válida.");
    }
}

private static int menuBusqueda() {
    System.out.println("Seleccione cómo desea buscar al alumno:");
    System.out.println("1. Por Documento");
    System.out.println("2. Por ID");
    System.out.print("Ingrese su opción: ");
    return leer.nextInt();
}

private static void buscarPorDocumento() {
    leer.nextLine(); // Limpiar el buffer
    System.out.print("Ingrese el número de documento del alumno: ");
    String documento = leer.nextLine();

    Alumno alumno = serviceAlumno.porDocumento(documento);
    mostrarResultado(alumno);
}

private static void buscarPorId() {
    System.out.print("Ingrese el ID del alumno: ");
    int idAlumno = leer.nextInt();

    Alumno alumno = serviceAlumno.porId(idAlumno);
    mostrarResultado(alumno);
}

    private static void mostrarResultado(Alumno alumno) {
        if (alumno != null) {
            System.out.println("Alumno encontrado:");
            System.out.println("ID: " + alumno.getId());
            System.out.println("Nombre: " + alumno.getPersona().getNombres() +
                               " " + alumno.getPersona().getApellidos());
            System.out.println("Documento: " + alumno.getPersona().getNumeroDocumento());

            // Otras propiedades del alumno

            // Opciones para modificar o eliminar el alumno
            System.out.println("===============================================");
            System.out.println("Opciones:");
            System.out.println("1. Modificar Alumno");
            System.out.println("2. Eliminar Alumno");
            System.out.println("===============================================");
            System.out.print("Ingrese su opción: ");
            int opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    modificarAlumno(alumno);
                    break;
                case 2:
                    eliminarAlumno(alumno);
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } else {
            System.out.println("Alumno no encontrado.");
        }
    }

private static void modificarAlumno(Alumno alumno) {
    // Aquí puedes implementar la lógica para modificar el alumno en la base de datos
    // Puedes utilizar el servicio serviceAlumno para realizar las operaciones necesarias
    // por ejemplo: serviceAlumno.editar(alumno);
    System.out.println("Implementa la lógica para modificar el alumno en la base de datos.");
}

private static void eliminarAlumno(Alumno alumno) {
    // Aquí puedes implementar la lógica para eliminar el alumno en la base de datos
    // Puedes utilizar el servicio serviceAlumno para realizar las operaciones necesarias
    // por ejemplo: serviceAlumno.eliminar(alumno);
    System.out.println("Implementa la lógica para eliminar el alumno en la base de datos.");
}

    private static void modificarAlumno() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el número de documento del alumno a modificar: ");
        String documento = scanner.nextLine();

        Alumno alumnoExistente = serviceAlumno.porDocumento(documento);

        if (alumnoExistente != null) {
            // Mostrar información del alumno existente
            System.out.println("Información actual del alumno:");
            System.out.println("ID: " + alumnoExistente.getId());
            System.out.println("Nombre: " + alumnoExistente.getPersona().getNombres() +
                               " " + alumnoExistente.getPersona().getApellidos());

            // Solicitar nuevos datos al usuario
            System.out.print("Ingrese el nuevo nombre del alumno: ");
            String nuevoNombre = scanner.next();

            System.out.print("Ingrese el nuevo apellido del alumno: ");
            String nuevoApellido = scanner.next();

            // Actualizar los datos del alumno
            alumnoExistente.getPersona().setNombres(nuevoNombre);
            alumnoExistente.getPersona().setApellidos(nuevoApellido);

            // Llamar al servicio para actualizar el alumno
            serviceAlumno.editar(alumnoExistente);

            System.out.println("Alumno actualizado correctamente.");
        } else {
            System.out.println("No se encontró un alumno con el número de documento proporcionado.");
        }
    }

    private static void eliminarAlumno() {

    System.out.print("Ingrese el ID del alumno a eliminar: ");
    String documento = scanner.nextLine();

    // Retrieve the Alumno based on the ID
    Alumno alumnoAEliminar = serviceAlumno.porDocumento(documento);

    if (alumnoAEliminar != null) {
        // Llamar al servicio para eliminar el alumno
        serviceAlumno.eliminar(alumnoAEliminar);
        System.out.println("Alumno eliminado correctamente.");
    } else {
        System.out.println("No se encontró un alumno con el ID proporcionado.");
    }
}

    private static void crearAlumno() {
    System.out.println("Creación de Nuevo Alumno");

    // Solicitar información al usuario
    System.out.print("Tipo de Documento (DNI, CI, Pasaporte, etc.): ");
    String tipoDocumento = leer.nextLine();

    System.out.print("Número de Documento: ");
    int numeroDocumento = leer.nextInt();

    leer.nextLine(); // Limpiar el buffer

    System.out.print("Nombres: ");
    String nombres = leer.nextLine();

    System.out.print("Apellidos: ");
    String apellidos = leer.nextLine();

    System.out.print("Dirección: ");
    String direccion = leer.nextLine();

    System.out.print("Teléfono: ");
    int telefono = leer.nextInt();

    leer.nextLine(); // Limpiar el buffer

    System.out.print("Fecha de Nacimiento (YYYY-MM-DD): ");
    String fechaNacimientoStr = leer.nextLine();
    Date fechaNacimiento = Date.valueOf(fechaNacimientoStr);

    System.out.print("Sexo: ");
    String sexo = leer.nextLine();

    // Crear un objeto Persona con la información proporcionada
    Persona persona = new Persona(0, tipoDocumento, numeroDocumento, nombres, apellidos, direccion, telefono, fechaNacimiento, sexo);

    // Llamar al servicio para guardar la persona en la base de datos
    int idPersona = servicePersona.crearPersona(persona);

    if (idPersona != -1) {
        // Crear un objeto Alumno asociado a la persona
        Alumno alumno = new Alumno(new Persona(idPersona, tipoDocumento, numeroDocumento, nombres, apellidos, direccion, telefono, fechaNacimiento, sexo), 0);
        System.out.println("Error al crear el alumno.");
    } else {
        System.out.println("Error al crear la persona.");
    }
  
}
}
