/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.views;

import com.packag.proyectos.Services.ServiceAlumno;
import com.packag.proyectos.models.Alumno;
import java.util.List;
import java.util.Scanner;




public class ViewAlumno extends ViewMain {
    
    

    private static final Scanner scanner = new Scanner(System.in);

    public static void startMenu() {
        int op = 0;

        do {
            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearAlumno();
                    break;
                case 2:
                    listarAlumnos();
                    break;
                case 3:
                    buscarAlumno();
                    break;
                case 4:
                    modificarAlumno();
                    break;
                case 5:
                    eliminarAlumno();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);
    }

    public static int mostrarMenu() {
        System.out.println("---- Menú ----");
        System.out.println("1. Crear Alumno");
        System.out.println("2. Listar Alumnos");
        System.out.println("3. Buscar Alumno");
        System.out.println("4. Modificar Alumno");
        System.out.println("5. Eliminar Alumno");
        System.out.println("0. Salir");
        System.out.println("Ingrese su opción: ");

        return scanner.nextInt();
    }

    public static void buscarAlumnos() {
        System.out.println("Busqueda de Alumnos ");
        leer.nextLine();
        System.out.print("Documento: ");
        String documento = leer.nextLine();

        Alumno alumno = serviceAlumno.porDocumento(documento);
        System.out.println();
        alumno.imprimir();
    }

    public static void listarAlumnos() {
        List<Alumno> alumnos = serviceAlumno.listar();

        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos registrados.");
        } else {
            System.out.println("Lista de Alumnos:");
            for (Alumno alumno : alumnos) {
                System.out.println("ID: " + alumno.getId() +
                        ", Nombre: " + alumno.getPersona().getNombres() +
                        " " + alumno.getPersona().getApellidos());
            }
        }
    }

    private static void buscarAlumno() {
        leer.nextLine();
        System.out.println("Ingrese el número de documento del alumno:");
        String documento = leer.nextLine();
        
        {
        Alumno alumno = serviceAlumno.porDocumento(documento);

        if (alumno != null) {
            System.out.println("Alumno encontrado: " + alumno);
            
        } else {
            System.out.println("Alumno no encontrado");
        }
    }
}
    private static void modificarAlumno() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el número de documento del alumno a modificar: ");
        String documento = scanner.nextLine();

        Alumno alumnoExistente = serviceAlumno.porDocumento(documento);

        if (alumnoExistente != null) {
            // Mostrar información del alumno existente
            System.out.println("Información actual del alumno:");
            System.out.println("ID: " + alumnoExistente.getId());
            System.out.println("Nombre: " + alumnoExistente.getPersona().getNombres() +
                               " " + alumnoExistente.getPersona().getApellidos());

            // Solicitar nuevos datos al usuario
            System.out.print("Ingrese el nuevo nombre del alumno: ");
            String nuevoNombre = scanner.next();

            System.out.print("Ingrese el nuevo apellido del alumno: ");
            String nuevoApellido = scanner.next();

            // Actualizar los datos del alumno
            alumnoExistente.getPersona().setNombres(nuevoNombre);
            alumnoExistente.getPersona().setApellidos(nuevoApellido);

            // Llamar al servicio para actualizar el alumno
            serviceAlumno.editar(alumnoExistente);

            System.out.println("Alumno actualizado correctamente.");
        } else {
            System.out.println("No se encontró un alumno con el número de documento proporcionado.");
        }
    }

    private static void eliminarAlumno() {

    System.out.print("Ingrese el ID del alumno a eliminar: ");
    String documento = scanner.nextLine();

    // Retrieve the Alumno based on the ID
    Alumno alumnoAEliminar = serviceAlumno.porDocumento(documento);

    if (alumnoAEliminar != null) {
        // Llamar al servicio para eliminar el alumno
        serviceAlumno.eliminar(alumnoAEliminar);
        System.out.println("Alumno eliminado correctamente.");
    } else {
        System.out.println("No se encontró un alumno con el ID proporcionado.");
    }
}

    private static void crearAlumno() {
    }
}