/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Services.ServiceImpl;

import com.packag.proyectos.Services.ServiceAlumno;
import com.packag.proyectos.models.Alumno;
import com.packag.proyectos.repository.AlumnoRepository;
import java.util.List;


/**
 *
 * @author Jefferson Jair
 */
public class ServiceAlumnoImpl  implements ServiceAlumno {

    private final AlumnoRepository crudRepositoryAlumno;

    public ServiceAlumnoImpl(AlumnoRepository crudRepositoryAlumno){
         this.crudRepositoryAlumno=crudRepositoryAlumno;
    }

    @Override
     public List<Alumno> listar() {
         return this.crudRepositoryAlumno.listar();
    }

    @Override
    public Alumno porDocumento(String documento) {
    Alumno alumno = (Alumno) this.crudRepositoryAlumno.porDocumento(documento);
        return alumno;
    }

    @Override
    public void crear(Alumno alumno) {
            this.crudRepositoryAlumno.crear(alumno);
                    }

    @Override
    public void editar(Alumno alumno) {
            this.crudRepositoryAlumno.editar(alumno);
    }

    @Override
    public void eliminar(Alumno alumno) {
            this.crudRepositoryAlumno.eliminar(alumno);
    }

    @Override
    public Alumno porId(int id) {
    Alumno alumno = this.crudRepositoryAlumno.porId(id);   
            return alumno;
 }


}


   
