/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.repository;

import com.packag.proyectos.models.Tarifa;
import java.util.List;

/**
 *
 * @author Jefferson Jair
 */
public interface TarifasRepository {
    List<Tarifa> listarTarifas();
    Tarifa obtenerTarifaPorId(int id);
    void crearTarifa(Tarifa tarifa);
    void editarTarifa(int id, Tarifa tarifa);
    void eliminarTarifa(int id);
}
