package com.packag.proyectos.views;



import com.packag.proyectos.models.Persona;
import static com.packag.proyectos.views.ViewMain.leer;
import java.sql.Date;
import java.util.List;
import java.util.Optional;

public class ViewPersona extends ViewMain {
    
   
    public static void startMenu() {
        int op = 0;

        do {
            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearPersona();
                    break;
                case 2:
                    listarPersonas();
                    break;
                case 3:
                    buscarPersona();
                    break;
                case 4:
                    modificarPersona();
                    break;
                case 5:
                    eliminarPersona();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);
    }

    public static int mostrarMenu() {
        System.out.println("----Menu--Persona----");
        System.out.println("1. Crear persona.");
        System.out.println("2. Listar personas.");
        System.out.println("3. Buscar persona.");
        System.out.println("4. Modificar persona.");
        System.out.println("5. Eliminar persona.");
        System.out.println("6. Salir ");
        return leer.nextInt();
    }

        private static void crearPersona() {
        leer.nextLine(); // Limpiar el buffer
        
        System.out.print("id: ");
        int id = leer.nextInt();
        leer.nextLine(); // Limpiar el buffer 
        
        System.out.print("Tipo de Documento: ");
        String tipoDocumento = leer.nextLine();

        System.out.print("Numero de Documento: ");
        int numeroDocumento = leer.nextInt();
        leer.nextLine(); // Limpiar el buffer 

        System.out.print("Nombres: ");
        String nombres = leer.nextLine();

        System.out.print("Apellidos: ");
        String apellidos = leer.nextLine();

        System.out.print("Direccion: ");
        String direccion = leer.nextLine();

        System.out.print("Telefono: ");
        int telefono = leer.nextInt();
        leer.nextLine(); // Limpiar el buffer 

        System.out.print("Fecha de Nacimiento (YYYY-MM-DD): ");
        String fechaNacimientoStr = leer.nextLine();
        Date fechaNacimiento = Date.valueOf(fechaNacimientoStr);

        System.out.print("Sexo: ");
        String sexo = leer.nextLine();

        // Crear un objeto Persona con la información proporcionada
        Persona persona = new Persona(id, tipoDocumento, numeroDocumento, nombres, apellidos, direccion, telefono, fechaNacimiento, sexo);

        // Llamar al servicio para guardar la persona en la base de datos
        int idPersona = servicePersona.crearPersona(persona);

        if (idPersona != -1) {
            System.out.println("Persona creada exitosamente con ID: " + idPersona);
        } else {
            System.out.println("Error al crear la persona.");
        }
    }

    private static void buscarPersona() {
    System.out.println("Búsqueda de Persona");
    leer.nextLine();

    System.out.println("=================================");
    System.out.println("Seleccione una opción de búsqueda:");
    System.out.println("=================================");
    System.out.println("1. Buscar por ID");
    System.out.println("2. Buscar por Documento");
    System.out.println("=================================");
    System.out.print("Ingrese su opción: ");


    int opcionBusqueda = leer.nextInt();
    leer.nextLine(); // Limpiar el buffer

    switch (opcionBusqueda) {
        case 1:
            System.out.print("ID: ");
            int idPersona = leer.nextInt();
            buscarPersonaPorId(idPersona);
            break;
        case 2:
            System.out.print("Documento: ");
            int numeroDocumento = leer.nextInt();
            buscarPersonaPorDocumento(numeroDocumento);
            break;
        default:
            System.out.println("Opción no válida.");
            break;
    }
}

private static void buscarPersonaPorId(int idPersona) {
    Persona personaEncontrada = servicePersona.obtenerPersonaPorId(idPersona);

    if (personaEncontrada != null) {
        System.out.println("\nPersona encontrada:\n");
        personaEncontrada.imprimir();
    } else {
        System.out.println("Persona no encontrada.");
    }
}

private static void buscarPersonaPorDocumento(int numeroDocumento) {
    // Obtener la lista actualizada de personas desde la base de datos
    List<Persona> listaPersonas = servicePersona.listarPersonas();

    // Realizar la búsqueda dentro de la lista
    Optional<Persona> personaEncontrada = listaPersonas.stream()
            .filter(persona -> persona.getNumeroDocumento() == numeroDocumento)
            .findFirst();

    if (personaEncontrada.isPresent()) {
        System.out.println("\nPersona encontrada:\n");
        personaEncontrada.get().imprimir();
    } else {
        System.out.println("Persona no encontrada.");
    }
}


        private static void modificarPersona() {
        System.out.println("=====================================");
        System.out.println("         Modificación de persona");
        System.out.println("=====================================");

        leer.nextLine();
        System.out.print("Documento de la persona a modificar: ");
        int numeroDocumento = leer.nextInt();

        // Obtener la persona desde la base de datos
        Persona personaAModificar = (Persona) servicePersona.obtenerPersonaPorDocumento(numeroDocumento);

        if (personaAModificar != null) {
            // Solicitar al usuario qué campos desea modificar
            System.out.println("Seleccione los campos a modificar:");
            System.out.println("1. Teléfono");
            System.out.println("2. Dirección");

            System.out.print("Ingrese el número de opción: ");
            int opcion = leer.nextInt();

            // Modificar los campos seleccionados
            modificarDatosPersona(personaAModificar, opcion);

            // Modificar en la base de datos
            servicePersona.editarPersona(personaAModificar.getId(), personaAModificar);

            System.out.println("Persona modificada correctamente.");
        } else {
            System.out.println("Persona no encontrada.");
        }
    }

    private static void modificarDatosPersona(Persona persona, int opcion) {
        System.out.println("Modificación de datos:");

        leer.nextLine(); // Limpiar el buffer

        switch (opcion) {
            case 1:
                System.out.print("Nuevo teléfono: ");
                int nuevoTelefono = leer.nextInt();
                persona.setTelefono(nuevoTelefono);
                break;
            case 2:
                System.out.print("Nueva dirección: ");
                String nuevaDireccion = leer.nextLine();
                persona.setDireccion(nuevaDireccion);
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }


    private static void eliminarPersona() {
    System.out.println("Eliminación de persona");
    leer.nextLine();

    System.out.print("Documento de la persona a eliminar: ");
    int id = leer.nextInt();

    // Eliminar de la base de datos
    servicePersona.eliminarPersona(id);

    System.out.println("Persona eliminada correctamente.");

}

    private static void listarPersonas() {
        System.out.println("Lista de Personas");

    List<Persona> listaPersonas = servicePersona.listarPersonas();

    if (listaPersonas.isEmpty()) {
        System.out.println("No hay personas registradas.");
    } else {
        for (Persona persona : listaPersonas) {
            if (persona != null) {
                persona.imprimir();
                System.out.println();
            } else {
                System.out.println("Error: Persona es null en la lista.");
                  }
            }
        }
    }
}