/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.packag.proyectos.Excepciones.ExcepcionesPersona;

/**
 *
 * @author Jefferson Jair
 */
public class PersonaNullException extends PersonaException{

    public PersonaNullException(String mensaje){
        super(mensaje);
    }
    
}

